"""Command line helper: python manage.py [migrate|seed|run|kpis]"""
import sys

from app import create_app
from apps.core import db


def main(argv):
    cmd = argv[1] if len(argv) > 1 else "run"
    app = create_app()
    if cmd == "migrate":
        with app.app_context():
            conn = db.connect(app.config["DATABASE_PATH"])
            print("applied:", db.run_migrations(conn) or "nothing new")
    elif cmd == "seed":
        from scripts.seed_demo_data import seed
        with app.app_context():
            print(seed())
    elif cmd == "kpis":
        from scripts.compute_kpis import compute
        with app.app_context():
            for k, v in compute(app).items():
                print(f"{k}: {v}")
    elif cmd == "run":
        app.run(host=app.config.get("HOST", "127.0.0.1"), port=int(app.config.get("PORT", 5000)))
    else:
        print(__doc__)


if __name__ == "__main__":
    main(sys.argv)
