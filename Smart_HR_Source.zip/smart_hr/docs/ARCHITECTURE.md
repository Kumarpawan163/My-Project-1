# Architecture and schema notes

![ER diagram](er_diagram.png)

## Layers
| Concern | Location |
|---------|----------|
| Routes / views (HTTP only) | `apps/<app>/routes.py` |
| Business logic (rules, state machines) | `apps/<app>/services.py` |
| Data access, migrations | `apps/core/db.py`, `migrations/*.sql` |
| Authentication, RBAC, CSRF | `apps/core/security.py` |
| Audit trail, email notifications, validation, logging | `apps/core/audit.py`, `notifications.py`, `validators.py`, `logging_setup.py` |
| Frontend | `templates/`, `static/` (dependency-free SVG charts) |

Apps: `accounts`, `employees` (incl. departments), `attendance`, `leave_management`, `payroll`, `reports` (dashboard, exports, audit, email log).

## Role-permission matrix
| Capability | Admin | HR | Employee |
|------------|:-----:|:--:|:--------:|
| Sign in, own dashboard/profile | yes | yes | yes |
| Check in/out, apply for leave, view own payslips | yes | yes | yes |
| Manage employees and departments | yes | yes | no |
| Correct attendance (reason required) | yes | yes | no |
| Approve / reject leave (not own request) | yes | yes | no |
| Salary components, payroll records, generate payslips | yes | yes | no |
| Mark payroll as paid | yes | no | no |
| Reports and exports, audit history, email log | yes | yes | no |
| Download a payslip | any | any | own, only after generation |

## Rules enforced server-side
- Attendance: one record per employee per day; late after `LATE_AFTER`; check-out must follow check-in; corrections need a reason and are audited and emailed.
- Leave: weekends not counted; no past start; no overlap with pending/approved requests; balance per leave type; transitions `pending -> approved|rejected|cancelled`, `approved -> cancelled`; rejection needs remarks; nobody decides their own request; approved leave marks attendance `on_leave`.
- Payroll: net = earnings - deductions; records skipped when deductions exceed gross; paid records are not overwritten; payslips downloadable by the owner only after HR generates them.
- Security: password hashing, session cookies (HttpOnly, SameSite=Lax), CSRF tokens on every form post, CSP and other headers, formula-injection protection in CSV/Excel exports, JSON 401/403 for `/api/`.

## Audit and notifications
`audit_logs` records employee, leave, attendance, salary, payroll and export actions with actor and details.
`notification_logs` records every email attempt as `sent` or `failed`; delivery failures never roll back the business action.
