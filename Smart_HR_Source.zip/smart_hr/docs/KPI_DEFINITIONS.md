# Core KPI definitions and evaluation results

Measured with `python -m scripts.compute_kpis --tests` against the **synthetic** demo database
(24 employees, 673 attendance rows, 12 leave requests, 48 payroll records). Results are in `docs/kpi_results.json`.

| # | Metric | Calculation method | Source data | Interpretation | Result |
|---|--------|--------------------|-------------|----------------|--------|
| 1a | Employee profile completeness | Mean share of 5 profile fields filled (name, phone, job title, department, joining date) | `employees` | 100% = every profile is complete | 100.0% |
| 1b | Duplicate employee records | Count of groups sharing the same lower-cased name + joining date | `employees` | Target 0; email and code are also DB-unique | 0 |
| 2a | Attendance recording coverage | Attendance rows in the last 30 days / (weekdays x active employees) | `attendance`, `employees` | Gaps are days nobody recorded or HR corrected | 95.5% |
| 2b | Monthly report accuracy | Sum of `days_recorded` in the monthly report equals a raw row count for the month | `attendance` | 100% = report agrees with source records | 100.0% |
| 3a | Average leave approval turnaround | Mean hours between `created_at` and `decided_at` for approved/rejected requests | `leave_requests` | Lower is better; seeded decisions take 3-40 h | 19.2 h |
| 3b | Pending leave requests | Count of requests with status `pending` | `leave_requests` | Backlog indicator shown on the HR dashboard | 2 |
| 4a | Payroll record completeness | Employees with at least one earning component / active employees | `salary_components` | 100% = every active employee can be paid | 100.0% |
| 4b | Payslip issuance rate | Payroll records with a generated payslip / all payroll records | `payroll_records` | Generation failures are not separately logged (see limitations), so this measures issuance, not error rate. The latest period is intentionally part-issued in the demo | 66.7% |
| 5 | Email notification success rate | `sent` / total rows in `notification_logs` | `notification_logs` | Console backend always succeeds; the SMTP failure path is covered by a test | 100% (34 emails) |
| 6 | Dashboard / report response time | Median of 15 in-process requests (Flask test client, no network) | `/api/v1/dashboard/charts`, `/reports/attendance.csv` | Small synthetic dataset on SQLite; not a load test | 0.4 ms / 1.7 ms |
| 7 | Automated test pass rate | Passed / total from pytest (role permissions, payroll access, state transitions, validation, exports) | `tests/` | 100% required before delivery | 86 / 86 = 100% |

## Notes
- Timings were taken in-process on one machine; they say nothing about production latency or large datasets.
- Re-run the script after seeding or changing data; numbers depend on the seeded dataset.
