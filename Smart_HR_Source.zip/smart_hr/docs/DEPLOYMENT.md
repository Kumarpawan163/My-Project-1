# Deployment guide

1. Provision Python 3.11+ and create a virtualenv: `python -m venv .venv && . .venv/bin/activate`.
2. `pip install -r requirements.txt gunicorn`.
3. Copy `.env.example` to `.env`; set a long random `SECRET_KEY`, `DEBUG=false`, `DATABASE_PATH` on a persistent volume, and SMTP settings with `EMAIL_BACKEND=smtp`.
4. `python manage.py migrate` (migrations also run automatically on start).
5. Do **not** run the seed script in production; create the first admin through a one-off script or SQL insert with a hashed password.
6. Run behind HTTPS: `gunicorn -w 3 -b 0.0.0.0:8000 "app:create_app()"` and put nginx/Caddy in front. Set `SESSION_COOKIE_SECURE=True` when serving over HTTPS.
7. Back up the SQLite file regularly (`sqlite3 smart_hr.sqlite3 ".backup backup.db"`).

## Docker (optional)
```
FROM python:3.12-slim
WORKDIR /app
COPY . .
RUN pip install --no-cache-dir -r requirements.txt gunicorn
ENV DATABASE_PATH=/data/smart_hr.sqlite3
VOLUME /data
CMD ["gunicorn", "-w", "3", "-b", "0.0.0.0:8000", "app:create_app()"]
```
The Dockerfile above was not built or run in this environment.

## Moving to the specified stack
The spec names Django, DRF, PostgreSQL, Celery/Redis and Chart.js. See README "Deviations from the brief" for what was used instead and how the service layer maps onto Django apps.
