# Smart HR & Employee Management System

Project 1 of the Python Development Internship: a web application for managing employees, departments, attendance, leave requests and payroll, with Admin / HR / Employee roles, email notifications, audit history, dashboards and downloadable reports.

> **Deviations from the brief (please read).** The brief specifies Django, Django REST Framework, PostgreSQL, Chart.js, and Celery/Redis. The environment this was built in had none of Django, DRF, PostgreSQL drivers, Celery or Redis installed and no network access to install them, so the application was built with **Flask + SQLite** (plus ReportLab and openpyxl for PDF/Excel) so that it could be run, tested and demonstrated. Charts are dependency-free SVG instead of Chart.js, a JSON API under `/api/v1/` stands in for DRF endpoints, and email is sent synchronously (no Celery). The module layout (`accounts`, `employees`, `attendance`, `leave_management`, `payroll`, `reports`), roles, workflows and deliverables follow the brief. A Django port is a straightforward follow-up because business rules live in framework-independent `services.py` modules.

## Features
- Secure login with role-based authorization (Admin, HR, Employee), CSRF protection, hashed passwords
- Employee profiles, departments, employment status, search / filter / pagination
- Attendance check-in/out, late detection, HR corrections with mandatory reason, monthly summaries
- Leave application, balances, approval / rejection with remarks, status history, invalid-transition protection
- Salary components, payroll periods and records, controlled payslip PDF generation/download
- Email templates with a sent/failed notification log (console or SMTP backend)
- Audit history for sensitive employee, leave, attendance and payroll changes
- Dashboard cards and charts; CSV / Excel / PDF exports for authorized roles

## Quick start
```bash
python -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env            # then set SECRET_KEY
python manage.py migrate        # creates the SQLite database (also runs automatically on start)
python manage.py seed           # synthetic demo data
python manage.py run            # http://127.0.0.1:5000
```

### Environment variables (`.env.example`)
`SECRET_KEY` (required), `DEBUG`, `DATABASE_PATH`, `LOG_LEVEL`, `EMAIL_BACKEND` (`console`|`smtp`), `SMTP_HOST/PORT/USER/PASSWORD`, `DEFAULT_FROM_EMAIL`, `LATE_AFTER`, `PAGE_SIZE`. Secrets are never committed; `.env` is git-ignored.

### Demo accounts (synthetic, created by the seed script)
| Role | Email | Password |
|------|-------|----------|
| Admin | admin@demo.example | Admin@12345 |
| HR | hr@demo.example | Hr@12345 |
| Employee | employee@demo.example | Employee@123 |

About 20 more synthetic employees use the password `Employee@123`.

## Tests
```bash
pytest -q          # 86 tests: permissions, validation, state transitions, payroll access, exports, notification failures
python -m scripts.compute_kpis --tests   # KPI report -> docs/kpi_results.json
```

## Core user journeys to demo (end to end, synthetic data)
1. HR signs in, reviews the dashboard, searches employees, creates an employee.
2. HR corrects an attendance record (reason required) and views the monthly summary.
3. Employee checks in and applies for leave; overlapping/over-balance requests are refused.
4. HR approves one request and rejects another with remarks; the employee is emailed.
5. HR generates a payslip; the employee downloads it. Admin marks payroll as paid.
6. HR exports reports and reviews the audit history and email log.
7. Employee attempts `/payroll/` and receives *Access denied*.

Screenshots are in `docs/screenshots/`.

## Documentation
- `docs/ARCHITECTURE.md` - layers, role-permission matrix, rules, ER diagram (`docs/er_diagram.png`)
- `docs/KPI_DEFINITIONS.md` - KPI calculation methods and measured results
- `docs/DEPLOYMENT.md` - deployment notes

## Project layout
```
config/  apps/{core,accounts,employees,attendance,leave_management,payroll,reports}/
templates/  static/  migrations/  scripts/{seed_demo_data.py,compute_kpis.py}  tests/  docs/
.env.example  requirements.txt  app.py  manage.py
```

## Known limitations
- Flask + SQLite instead of Django + PostgreSQL (see top); SQLite suits demos and small teams, not heavy concurrent writes.
- No Celery/Redis: emails are sent inline; a slow SMTP server slows the request (failures are logged, not fatal).
- No login rate limiting, password reset or 2FA; sessions are server-signed cookies.
- Payroll does not model tax rules, loss-of-pay from absences, or period close/lock beyond the `status` column.
- Payslip generation failures are not logged separately, so the "payslip success rate" KPI measures issuance.
- Docker and SMTP delivery paths were not exercised against real services; SMTP failure handling is covered by a test.
- Performance figures come from a small synthetic dataset, in-process.
