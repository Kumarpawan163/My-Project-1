"""Seed SYNTHETIC demo data. No real people, payroll figures or credentials are used.

Run:  python manage.py seed
Accounts (demo only):
  admin@demo.example      / Admin@12345
  hr@demo.example         / Hr@12345
  employee@demo.example   / Employee@123   (plus ~20 more employees, same password)
"""
import random
from datetime import date, datetime, timedelta

from werkzeug.security import generate_password_hash

from apps.core.db import get_db, query
from apps.leave_management import services as leave
from apps.payroll import services as payroll

DEPARTMENTS = [
    ("Engineering", "Product development and platform"), ("Human Resources", "People operations"),
    ("Sales", "Revenue and accounts"), ("Finance", "Accounting and payroll"), ("Operations", "Delivery and support"),
]
FIRST = ["Aarav", "Diya", "Kabir", "Meera", "Rohan", "Isha", "Vikram", "Anaya", "Arjun", "Sara", "Neil", "Tara",
         "Dev", "Nisha", "Karan", "Leela", "Omar", "Priya", "Samir", "Zoya", "Ravi", "Maya"]
LAST = ["Rao", "Shah", "Khan", "Iyer", "Nair", "Patel", "Das", "Mehta", "Bose", "Menon", "Joshi", "Kapoor"]
TITLES = {"Engineering": ["Software Engineer", "QA Engineer", "Tech Lead"], "Human Resources": ["HR Executive", "Recruiter"],
          "Sales": ["Account Executive", "Sales Associate"], "Finance": ["Accountant", "Payroll Analyst"], "Operations": ["Support Specialist", "Coordinator"]}


def _add_employee(db, email, password, role, name, dept_id, title, joined, code, status="active"):
    uid = db.execute("INSERT INTO users (email, password_hash, role) VALUES (?, ?, ?)", (email, generate_password_hash(password), role)).lastrowid
    return db.execute(
        "INSERT INTO employees (user_id, employee_code, full_name, phone, job_title, department_id, employment_status, joining_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        (uid, code, name, "+91-90000-%05d" % (10000 + uid), title, dept_id, status, joined),
    ).lastrowid


def _next_weekday(d):
    while d.weekday() >= 5:
        d += timedelta(days=1)
    return d


def seed(today=None):
    today = today or date.today()
    db = get_db()
    if query("SELECT 1 FROM users LIMIT 1", one=True):
        return "database already contains data; nothing seeded"
    rnd = random.Random(2026)

    for name, desc in DEPARTMENTS:
        db.execute("INSERT INTO departments (name, description) VALUES (?, ?)", (name, desc))
    dept = {r["name"]: r["id"] for r in query("SELECT * FROM departments")}
    for name, allowance in (("Annual", 18), ("Sick", 10), ("Casual", 6)):
        db.execute("INSERT INTO leave_types (name, annual_allowance) VALUES (?, ?)", (name, allowance))

    people = [
        ("admin@demo.example", "Admin@12345", "admin", "Asha Verma", "Human Resources", "Operations Director"),
        ("hr@demo.example", "Hr@12345", "hr", "Hari Menon", "Human Resources", "HR Manager"),
        ("employee@demo.example", "Employee@123", "employee", "Esha Rao", "Engineering", "Software Engineer"),
    ]
    used = {p[3] for p in people}
    names = [f"{f} {l}" for f in FIRST for l in LAST]
    rnd.shuffle(names)
    extra = [n for n in names if n not in used][:21]
    for n in extra:
        d = rnd.choice(list(TITLES))
        people.append((n.lower().replace(" ", ".") + "@demo.example", "Employee@123", "employee", n, d, rnd.choice(TITLES[d])))

    emp_ids = []
    for i, (email, pw, role, name, d, title) in enumerate(people, 1):
        joined = (today - timedelta(days=rnd.randint(120, 1500))).isoformat()
        status = "on_leave" if i == 9 else "active"
        emp_ids.append(_add_employee(db, email, pw, role, name, dept[d], title, joined, f"EMP{i:04d}", status))
    db.commit()

    # Attendance for the last 40 days (weekdays only), synthetic distribution.
    for eid in emp_ids:
        for back in range(1, 41):
            day = today - timedelta(days=back)
            if day.weekday() >= 5:
                continue
            r = rnd.random()
            if r < 0.86:
                status, cin = "present", f"09:{rnd.randint(0, 25):02d}"
            elif r < 0.94:
                status, cin = "late", f"09:{rnd.randint(35, 59):02d}"
            elif r < 0.97:
                status, cin = "half_day", f"13:{rnd.randint(0, 20):02d}"
            else:
                status, cin = "absent", None
            cout = f"{rnd.randint(17, 18)}:{rnd.randint(0, 59):02d}" if cin else None
            db.execute("INSERT OR IGNORE INTO attendance (employee_id, work_date, check_in, check_out, status) VALUES (?, ?, ?, ?, ?)",
                       (eid, day.isoformat(), cin, cout, status))
    db.commit()

    # Historical leave decisions (gives a realistic turnaround KPI).
    hr_user = query("SELECT * FROM users WHERE email = 'hr@demo.example'", one=True)
    for k, eid in enumerate(emp_ids[3:11]):
        start = _next_weekday(today - timedelta(days=rnd.randint(8, 30)))
        end = start + timedelta(days=1)
        days = max(1, leave.working_days(start, end)) if hasattr(leave, "working_days") else 2
        status = "approved" if k % 4 else "rejected"
        created = datetime.now() - timedelta(days=rnd.randint(12, 35))
        decided = created + timedelta(hours=rnd.randint(3, 40))
        cur = db.execute(
            "INSERT INTO leave_requests (employee_id, leave_type_id, start_date, end_date, days, reason, status, reviewer_id, remarks, created_at, decided_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (eid, 1 + k % 3, start.isoformat(), end.isoformat(), days, "Personal commitment", status, hr_user["id"],
             "Approved" if status == "approved" else "Team capacity", created.strftime("%Y-%m-%d %H:%M:%S"), decided.strftime("%Y-%m-%d %H:%M:%S")),
        )
        db.execute("INSERT INTO leave_status_history (leave_request_id, from_status, to_status, changed_by, remarks) VALUES (?, NULL, 'pending', NULL, 'Submitted')", (cur.lastrowid,))
        db.execute("INSERT INTO leave_status_history (leave_request_id, from_status, to_status, changed_by, remarks) VALUES (?, 'pending', ?, ?, '')", (cur.lastrowid, status, hr_user["id"]))
    db.commit()

    # Live workflow items through the real service layer.
    employee_user = query("SELECT * FROM users WHERE email = 'employee@demo.example'", one=True)
    esha = query("SELECT * FROM employees WHERE user_id = ?", (employee_user["id"],), one=True)
    start = _next_weekday(today + timedelta(days=10))
    leave.apply(esha, employee_user, 1, start.isoformat(), (start + timedelta(days=2)).isoformat(), "Family function", today)
    for eid, offset in ((emp_ids[4], 14), (emp_ids[5], 17), (emp_ids[6], 21)):
        emp = query("SELECT e.*, u.id AS uid FROM employees e JOIN users u ON u.id = e.user_id WHERE e.id = ?", (eid,), one=True)
        s = _next_weekday(today + timedelta(days=offset))
        leave.apply(emp, {"id": emp["uid"]}, 3, s.isoformat(), s.isoformat(), "Personal errand", today)
    pending = query("SELECT id FROM leave_requests WHERE status = 'pending' ORDER BY id")
    leave.transition(pending[1]["id"], "approved", hr_user, "Enjoy your day")
    leave.transition(pending[2]["id"], "rejected", hr_user, "Release week - please reschedule")

    # Salary components (synthetic).
    for eid in emp_ids:
        basic = rnd.randrange(30000, 90000, 2500)
        for name, kind, amount in (("Basic", "earning", basic), ("HRA", "earning", round(basic * 0.4)), ("Transport", "earning", 2000),
                                   ("Provident fund", "deduction", round(basic * 0.12)), ("Income tax", "deduction", round(basic * 0.08))):
            db.execute("INSERT INTO salary_components (employee_id, name, kind, amount) VALUES (?, ?, ?, ?)", (eid, name, kind, amount))
    db.commit()

    # Payroll: previous two months, payslips issued for the older month.
    admin = query("SELECT * FROM users WHERE email = 'admin@demo.example'", one=True)
    ref = today.replace(day=1)
    for months_back in (2, 1):
        y, m = ref.year, ref.month - months_back
        while m < 1:
            m += 12
            y -= 1
        pid = payroll.create_period(y, m)
        payroll.generate_records(pid)
        if months_back == 2:
            for rec in payroll.records_for_period(pid):
                payroll.generate_payslip(rec["id"], hr_user)
                payroll.mark_paid(rec["id"], admin)
        elif months_back == 1:
            for rec in payroll.records_for_period(pid)[:8]:
                payroll.generate_payslip(rec["id"], hr_user)

    counts = {t: query(f"SELECT COUNT(*) AS c FROM {t}", one=True)["c"] for t in ("users", "employees", "attendance", "leave_requests", "payroll_records")}
    return f"seeded: {counts}"
