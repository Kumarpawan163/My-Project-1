"""Compute the Core KPIs documented in docs/KPI_DEFINITIONS.md against the current database.

Usage:  python -m scripts.compute_kpis            (uses DATABASE_PATH, writes docs/kpi_results.json)
"""
import json
import re
import statistics
import subprocess
import sys
import time
from datetime import date, timedelta
from pathlib import Path

from apps.attendance import services as attendance
from apps.core.db import query
from apps.employees.services import completeness
from apps.leave_management import services as leave
from apps.payroll import services as payroll

ROOT = Path(__file__).resolve().parent.parent


def _timed(client, url, runs=15):
    samples = []
    for _ in range(runs):
        t = time.perf_counter()
        resp = client.get(url)
        assert resp.status_code == 200, (url, resp.status_code)
        samples.append((time.perf_counter() - t) * 1000)
    return round(statistics.median(samples), 1)


def compute(app, run_tests=False):
    today = date.today()
    out = {}

    emps = query("SELECT * FROM employees")
    out["1_profile_completeness_pct"] = round(100 * sum(completeness(e) for e in emps) / len(emps), 1)
    dupes = query("SELECT COUNT(*) AS c FROM (SELECT 1 FROM employees GROUP BY lower(full_name), joining_date HAVING COUNT(*) > 1)", one=True)["c"]
    out["1_duplicate_employee_records"] = dupes

    start = today - timedelta(days=29)
    expected = sum(1 for i in range(30) if (start + timedelta(days=i)).weekday() < 5) * query(
        "SELECT COUNT(*) AS c FROM employees WHERE employment_status != 'terminated'", one=True)["c"]
    recorded = query("SELECT COUNT(*) AS c FROM attendance WHERE work_date BETWEEN ? AND ?", (start.isoformat(), today.isoformat()), one=True)["c"]
    out["2_attendance_coverage_pct"] = round(100 * min(recorded, expected) / expected, 1) if expected else 0
    rows = attendance.monthly_report(today.year, today.month)
    raw = query("SELECT COUNT(*) AS c FROM attendance a JOIN employees e ON e.id = a.employee_id WHERE a.work_date BETWEEN ? AND ? AND e.employment_status != 'terminated'", attendance.month_bounds(today.year, today.month), one=True)["c"]
    out["2_monthly_report_accuracy_pct"] = 100.0 if sum(r["days_recorded"] for r in rows) == raw else round(100 * sum(r["days_recorded"] for r in rows) / max(raw, 1), 1)

    lk = leave.kpis()
    out["3_avg_leave_turnaround_hours"] = round(lk["avg_turnaround_hours"], 1)
    out["3_pending_leave_requests"] = lk["pending"]

    pk = payroll.kpis()
    out["4_payroll_record_completeness_pct"] = round(100 * pk["record_completeness"], 1)
    out["4_payslip_generation_success_pct"] = round(100 * pk["payslip_success_rate"], 1)

    mail = query("SELECT COUNT(*) AS c, COALESCE(SUM(status='sent'), 0) AS ok FROM notification_logs", one=True)
    out["5_email_success_pct"] = round(100 * mail["ok"] / mail["c"], 1) if mail["c"] else None
    out["5_email_count"] = mail["c"]

    client = app.test_client()
    admin = query("SELECT id FROM users WHERE email = 'admin@demo.example'", one=True)
    with client.session_transaction() as s:
        s["user_id"] = admin["id"]
    out["6_dashboard_charts_ms_median"] = _timed(client, "/api/v1/dashboard/charts")
    out["6_attendance_report_csv_ms_median"] = _timed(client, "/reports/attendance.csv")
    out["6_dataset_employees"] = len(emps)
    out["6_dataset_attendance_rows"] = query("SELECT COUNT(*) AS c FROM attendance", one=True)["c"]

    if run_tests:
        proc = subprocess.run([sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider"], cwd=ROOT, capture_output=True, text=True)
        passed = sum(int(n) for n in re.findall(r"(\d+) passed", proc.stdout))
        failed = sum(int(n) for n in re.findall(r"(\d+) failed", proc.stdout))
        total = passed + failed
        out["7_tests_passed"], out["7_tests_total"] = passed, total
        out["7_test_pass_rate_pct"] = round(100 * passed / total, 1) if total else 0
    return out


if __name__ == "__main__":
    from app import create_app

    app = create_app()
    with app.app_context():
        result = compute(app, run_tests="--tests" in sys.argv)
    (ROOT / "docs").mkdir(exist_ok=True)
    (ROOT / "docs" / "kpi_results.json").write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))
