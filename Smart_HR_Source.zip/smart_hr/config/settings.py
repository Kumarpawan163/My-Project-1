"""Configuration loaded from environment variables (see .env.example)."""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent


def load_dotenv(path=None):
    """Minimal .env loader (python-dotenv is optional and not required)."""
    path = Path(path or BASE_DIR / ".env")
    if not path.exists():
        return
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


def _bool(name, default=False):
    return os.environ.get(name, str(default)).lower() in ("1", "true", "yes", "on")


class Config:
    def __init__(self, **overrides):
        load_dotenv()
        self.SECRET_KEY = os.environ.get("SECRET_KEY", "")
        self.DEBUG = _bool("DEBUG", False)
        self.DATABASE_PATH = os.environ.get("DATABASE_PATH", str(BASE_DIR / "instance" / "smart_hr.sqlite3"))
        self.EMAIL_BACKEND = os.environ.get("EMAIL_BACKEND", "console")  # console | smtp
        self.SMTP_HOST = os.environ.get("SMTP_HOST", "")
        self.SMTP_PORT = int(os.environ.get("SMTP_PORT", "587"))
        self.SMTP_USER = os.environ.get("SMTP_USER", "")
        self.SMTP_PASSWORD = os.environ.get("SMTP_PASSWORD", "")
        self.DEFAULT_FROM_EMAIL = os.environ.get("DEFAULT_FROM_EMAIL", "hr@example.com")
        self.LATE_AFTER = os.environ.get("LATE_AFTER", "09:30")
        self.PAGE_SIZE = int(os.environ.get("PAGE_SIZE", "8"))
        self.LOG_LEVEL = os.environ.get("LOG_LEVEL", "INFO")
        self.TESTING = False
        for key, value in overrides.items():
            setattr(self, key, value)
        if not self.SECRET_KEY:
            if self.DEBUG or self.TESTING:
                self.SECRET_KEY = "insecure-dev-key-do-not-use-in-production"
            else:
                raise RuntimeError("SECRET_KEY must be set (copy .env.example to .env).")
