/* Dependency-free SVG charts (bar + donut). Data comes from /api/v1/dashboard/charts. */
(function () {
  var PALETTE = ["#1f6feb", "#12a594", "#e8a317", "#d1435b", "#7a5af8", "#475467"];
  var STATUS = { present: "#12a594", late: "#e8a317", absent: "#d1435b", half_day: "#7a5af8", on_leave: "#1f6feb",
                 approved: "#12a594", pending: "#e8a317", rejected: "#d1435b", cancelled: "#98a2b3" };
  var NS = "http://www.w3.org/2000/svg";

  function el(name, attrs, text) {
    var n = document.createElementNS(NS, name);
    for (var k in attrs) n.setAttribute(k, attrs[k]);
    if (text !== undefined) n.textContent = text;
    return n;
  }
  function empty(node) { node.innerHTML = '<p class="sub">No data yet.</p>'; }

  function bars(node, data, colorFor) {
    if (!data.length) return empty(node);
    var W = 520, H = 230, pad = 34, max = Math.max.apply(null, data.map(function (d) { return d.value; })) || 1;
    var svg = el("svg", { viewBox: "0 0 " + W + " " + H, role: "img" });
    var bw = (W - pad * 2) / data.length;
    data.forEach(function (d, i) {
      var h = (H - pad * 2) * d.value / max, x = pad + i * bw + bw * 0.15, y = H - pad - h;
      svg.appendChild(el("rect", { x: x, y: y, width: bw * 0.7, height: h, rx: 5, fill: colorFor(d, i) }));
      svg.appendChild(el("text", { x: x + bw * 0.35, y: y - 6, "text-anchor": "middle", "font-size": 12, fill: "#344054" }, d.value));
      var label = String(d.label).length > 12 ? String(d.label).slice(0, 11) + "…" : d.label;
      svg.appendChild(el("text", { x: x + bw * 0.35, y: H - 12, "text-anchor": "middle", "font-size": 11, fill: "#667085" }, label));
    });
    svg.appendChild(el("line", { x1: pad, x2: W - pad, y1: H - pad, y2: H - pad, stroke: "#d0d5dd" }));
    node.appendChild(svg);
  }

  function donut(node, data) {
    if (!data.length) return empty(node);
    var total = data.reduce(function (s, d) { return s + d.value; }, 0), r = 70, c = 2 * Math.PI * r, off = 0;
    var svg = el("svg", { viewBox: "0 0 220 220", role: "img" });
    data.forEach(function (d) {
      var len = c * d.value / total;
      svg.appendChild(el("circle", { cx: 110, cy: 110, r: r, fill: "none", stroke: STATUS[d.label] || "#98a2b3", "stroke-width": 34,
        "stroke-dasharray": len + " " + (c - len), "stroke-dashoffset": -off, transform: "rotate(-90 110 110)" }));
      off += len;
    });
    svg.appendChild(el("text", { x: 110, y: 116, "text-anchor": "middle", "font-size": 26, "font-weight": 700, fill: "#14304f" }, total));
    node.appendChild(svg);
    var lg = document.createElement("div");
    lg.className = "legend";
    data.forEach(function (d) {
      lg.innerHTML += '<span><i style="background:' + (STATUS[d.label] || "#98a2b3") + '"></i>' + d.label.replace("_", " ") + " (" + d.value + ")</span>";
    });
    node.appendChild(lg);
  }

  function draw(id, fn) { var n = document.getElementById(id); if (n) fn(n); }

  fetch("/api/v1/dashboard/charts", { credentials: "same-origin" })
    .then(function (r) { return r.json(); })
    .then(function (d) {
      draw("chart-departments", function (n) { bars(n, d.departments, function (_, i) { return PALETTE[i % PALETTE.length]; }); });
      draw("chart-attendance", function (n) { bars(n, d.attendance, function (x) { return STATUS[x.label] || "#1f6feb"; }); });
      draw("chart-leave", function (n) { donut(n, d.leave); });
      draw("chart-payroll", function (n) { bars(n, d.payroll, function () { return "#14304f"; }); });
    });
})();
