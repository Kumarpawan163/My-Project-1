"""Leave workflow: application, validation, approval state machine and history."""
from datetime import date, timedelta

from apps.core import audit, notifications
from apps.core.db import get_db, query
from apps.core.validators import ValidationError, parse_date, require, working_days

TRANSITIONS = {
    "pending": {"approved", "rejected", "cancelled"},
    "approved": {"cancelled"},
    "rejected": set(),
    "cancelled": set(),
}


class PermissionDenied(Exception):
    pass


def leave_types():
    return query("SELECT * FROM leave_types ORDER BY name")


def balance(employee_id, leave_type_id, year):
    lt = query("SELECT * FROM leave_types WHERE id = ?", (leave_type_id,), one=True)
    used = query(
        "SELECT COALESCE(SUM(days), 0) AS d FROM leave_requests WHERE employee_id = ? AND leave_type_id = ? "
        "AND status IN ('pending', 'approved') AND substr(start_date, 1, 4) = ?",
        (employee_id, leave_type_id, str(year)),
        one=True,
    )["d"]
    return lt["annual_allowance"] - used


def balances(employee_id, year):
    return [{"type": lt["name"], "allowance": lt["annual_allowance"], "remaining": balance(employee_id, lt["id"], year)} for lt in leave_types()]


def _history(db, request_id, from_status, to_status, user_id, remarks):
    db.execute(
        "INSERT INTO leave_status_history (leave_request_id, from_status, to_status, changed_by, remarks) VALUES (?, ?, ?, ?, ?)",
        (request_id, from_status, to_status, user_id, remarks),
    )


def apply(employee, user, leave_type_id, start, end, reason, today=None):
    today = today or date.today()
    s, e = parse_date(start, "Start date"), parse_date(end, "End date")
    if e < s:
        raise ValidationError("End date cannot be before start date")
    if s < today:
        raise ValidationError("Leave cannot start in the past")
    lt = query("SELECT * FROM leave_types WHERE id = ?", (leave_type_id,), one=True)
    if lt is None:
        raise ValidationError("Select a valid leave type")
    reason = require(reason, "Reason")
    days = working_days(s, e)
    if days == 0:
        raise ValidationError("The selected range contains no working days")
    overlap = query(
        "SELECT 1 FROM leave_requests WHERE employee_id = ? AND status IN ('pending', 'approved') "
        "AND start_date <= ? AND end_date >= ?",
        (employee["id"], e.isoformat(), s.isoformat()),
        one=True,
    )
    if overlap:
        raise ValidationError("This request overlaps an existing pending or approved leave")
    if days > balance(employee["id"], lt["id"], s.year):
        raise ValidationError(f"Insufficient {lt['name']} balance for {days} day(s)")
    db = get_db()
    cur = db.execute(
        "INSERT INTO leave_requests (employee_id, leave_type_id, start_date, end_date, days, reason) VALUES (?, ?, ?, ?, ?, ?)",
        (employee["id"], lt["id"], s.isoformat(), e.isoformat(), days, reason),
    )
    _history(db, cur.lastrowid, None, "pending", user["id"], "Submitted")
    db.commit()
    audit.record("leave_request", cur.lastrowid, "submitted", f"{s}..{e} ({days}d)")
    return cur.lastrowid


def get_request(request_id):
    return query(
        "SELECT r.*, lt.name AS leave_type, e.full_name, e.employee_code, u.email, e.user_id AS owner_user_id "
        "FROM leave_requests r JOIN leave_types lt ON lt.id = r.leave_type_id "
        "JOIN employees e ON e.id = r.employee_id JOIN users u ON u.id = e.user_id WHERE r.id = ?",
        (request_id,),
        one=True,
    )


def history(request_id):
    return query(
        "SELECT h.*, u.email AS actor FROM leave_status_history h LEFT JOIN users u ON u.id = h.changed_by "
        "WHERE h.leave_request_id = ? ORDER BY h.id",
        (request_id,),
    )


def _weekdays(start, end):
    cur = parse_date(start)
    stop = parse_date(end)
    while cur <= stop:
        if cur.weekday() < 5:
            yield cur.isoformat()
        cur += timedelta(days=1)


def transition(request_id, new_status, actor, remarks=""):
    req = get_request(request_id)
    if req is None:
        raise ValidationError("Leave request not found")
    is_staff = actor["role"] in ("admin", "hr")
    is_owner = actor["id"] == req["owner_user_id"]
    if new_status not in TRANSITIONS.get(req["status"], set()):
        raise ValidationError(f"Invalid transition: {req['status']} -> {new_status}")
    if new_status in ("approved", "rejected"):
        if not is_staff:
            raise PermissionDenied("Only HR or Admin can approve or reject leave")
        if is_owner:
            raise PermissionDenied("You cannot decide your own leave request")
        if new_status == "rejected" and not (remarks or "").strip():
            raise ValidationError("Remarks are required when rejecting a request")
    elif new_status == "cancelled":
        if not (is_staff or (is_owner and req["status"] == "pending")):
            raise PermissionDenied("You cannot cancel this request")
    db = get_db()
    db.execute(
        "UPDATE leave_requests SET status = ?, reviewer_id = ?, remarks = ?, decided_at = datetime('now') WHERE id = ?",
        (new_status, actor["id"], (remarks or "").strip(), request_id),
    )
    _history(db, request_id, req["status"], new_status, actor["id"], (remarks or "").strip())
    if new_status == "approved":
        for day in _weekdays(req["start_date"], req["end_date"]):
            db.execute(
                "INSERT OR IGNORE INTO attendance (employee_id, work_date, status, corrected_by, correction_reason) VALUES (?, ?, 'on_leave', ?, 'Approved leave')",
                (req["employee_id"], day, actor["id"]),
            )
    elif new_status == "cancelled" and req["status"] == "approved":
        db.execute(
            "DELETE FROM attendance WHERE employee_id = ? AND status = 'on_leave' AND work_date BETWEEN ? AND ?",
            (req["employee_id"], req["start_date"], req["end_date"]),
        )
    db.commit()
    audit.record("leave_request", request_id, new_status, (remarks or "").strip())
    if not is_owner:
        notifications.send(
            "leave_decision", req["email"], name=req["full_name"], leave_type=req["leave_type"],
            start=req["start_date"], end=req["end_date"], status=new_status, remarks=(remarks or "-").strip() or "-",
        )


def list_requests(employee_id=None, status=""):
    where, params = ["1=1"], []
    if employee_id:
        where.append("r.employee_id = ?")
        params.append(employee_id)
    if status:
        where.append("r.status = ?")
        params.append(status)
    return query(
        "SELECT r.*, lt.name AS leave_type, e.full_name, e.employee_code FROM leave_requests r "
        "JOIN leave_types lt ON lt.id = r.leave_type_id JOIN employees e ON e.id = r.employee_id "
        f"WHERE {' AND '.join(where)} ORDER BY r.created_at DESC, r.id DESC",
        params,
    )


def kpis():
    row = query(
        "SELECT AVG((julianday(decided_at) - julianday(created_at)) * 24) AS hours FROM leave_requests WHERE status IN ('approved','rejected')",
        one=True,
    )
    pending = query("SELECT COUNT(*) AS c FROM leave_requests WHERE status = 'pending'", one=True)["c"]
    return {"avg_turnaround_hours": row["hours"] or 0.0, "pending": pending}
