from datetime import date

from flask import Blueprint, abort, flash, g, jsonify, redirect, render_template, request, url_for

from apps.core.security import login_required, roles_required
from apps.core.validators import ValidationError
from apps.leave_management import services
from apps.leave_management.services import PermissionDenied

bp = Blueprint("leave", __name__, url_prefix="/leave")


@bp.route("/")
@login_required
def mine():
    if g.employee is None:
        abort(404)
    return render_template(
        "leave/mine.html", requests=services.list_requests(g.employee["id"]),
        balances=services.balances(g.employee["id"], date.today().year),
    )


@bp.route("/apply", methods=["GET", "POST"])
@login_required
def apply():
    if g.employee is None:
        abort(403)
    if request.method == "POST":
        try:
            services.apply(g.employee, g.user, request.form.get("leave_type_id", type=int), request.form.get("start_date"), request.form.get("end_date"), request.form.get("reason"))
            flash("Leave request submitted.", "success")
            return redirect(url_for("leave.mine"))
        except ValidationError as exc:
            flash(str(exc), "error")
    return render_template("leave/apply.html", leave_types=services.leave_types(), form=request.form, today=date.today().isoformat())


@bp.route("/manage")
@roles_required("admin", "hr")
def manage():
    status = request.args.get("status", "pending")
    return render_template("leave/manage.html", requests=services.list_requests(status=status), status=status)


@bp.route("/<int:request_id>")
@login_required
def detail(request_id):
    req = services.get_request(request_id)
    if req is None:
        abort(404)
    if g.user["role"] == "employee" and req["owner_user_id"] != g.user["id"]:
        abort(403)
    return render_template("leave/detail.html", req=req, history=services.history(request_id))


@bp.route("/<int:request_id>/<action>", methods=["POST"])
@login_required
def act(request_id, action):
    mapping = {"approve": "approved", "reject": "rejected", "cancel": "cancelled"}
    if action not in mapping:
        abort(404)
    try:
        services.transition(request_id, mapping[action], g.user, request.form.get("remarks", ""))
        flash(f"Request {mapping[action]}.", "success")
    except PermissionDenied:
        abort(403)
    except ValidationError as exc:
        flash(str(exc), "error")
    return redirect(request.form.get("next") or url_for("leave.detail", request_id=request_id))


@bp.route("/api/v1/leave-requests")
@login_required
def api_list():
    emp_id = g.employee["id"] if g.user["role"] == "employee" else None
    rows = services.list_requests(emp_id, request.args.get("status", ""))
    return jsonify(results=[{k: r[k] for k in ("id", "employee_code", "full_name", "leave_type", "start_date", "end_date", "days", "status")} for r in rows])
