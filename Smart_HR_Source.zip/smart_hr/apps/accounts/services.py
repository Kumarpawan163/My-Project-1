"""Business logic for authentication and user accounts."""
from werkzeug.security import check_password_hash, generate_password_hash

from apps.core import audit
from apps.core.db import execute, query
from apps.core.security import ROLES
from apps.core.validators import ValidationError, valid_email

MIN_PASSWORD_LENGTH = 8


def authenticate(email, password):
    user = query("SELECT * FROM users WHERE email = ? AND is_active = 1", ((email or "").strip().lower(),), one=True)
    if user and check_password_hash(user["password_hash"], password or ""):
        return user
    return None


def create_user(email, password, role):
    email = valid_email(email)
    if role not in ROLES:
        raise ValidationError("Unknown role")
    if len(password or "") < MIN_PASSWORD_LENGTH:
        raise ValidationError(f"Password must be at least {MIN_PASSWORD_LENGTH} characters")
    if query("SELECT 1 FROM users WHERE email = ?", (email,), one=True):
        raise ValidationError("A user with this email already exists")
    uid = execute(
        "INSERT INTO users (email, password_hash, role) VALUES (?, ?, ?)",
        (email, generate_password_hash(password), role),
    )
    audit.record("user", uid, "created", f"role={role}")
    return uid
