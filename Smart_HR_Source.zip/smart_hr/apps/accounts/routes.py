from flask import Blueprint, flash, g, redirect, render_template, request, session, url_for

from apps.accounts import services
from apps.core import audit

bp = Blueprint("accounts", __name__)


@bp.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        user = services.authenticate(request.form.get("email"), request.form.get("password"))
        if user:
            session.clear()
            session["user_id"] = user["id"]
            g.user = user
            audit.record("user", user["id"], "login")
            nxt = request.args.get("next", "")
            return redirect(nxt if nxt.startswith("/") and not nxt.startswith("//") else url_for("reports.dashboard"))
        flash("Invalid email or password.", "error")
    return render_template("accounts/login.html")


@bp.route("/logout", methods=["POST"])
def logout():
    session.clear()
    return redirect(url_for("accounts.login"))
