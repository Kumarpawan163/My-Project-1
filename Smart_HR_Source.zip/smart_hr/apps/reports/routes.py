from datetime import date

from flask import Blueprint, Response, abort, flash, g, jsonify, redirect, render_template, request, url_for

from apps.attendance import services as attendance
from apps.core import audit
from apps.core.db import query
from apps.core.security import login_required, roles_required
from apps.core.validators import ValidationError
from apps.leave_management import services as leave
from apps.payroll import services as payroll
from apps.reports import services

bp = Blueprint("reports", __name__)


@bp.route("/")
@bp.route("/dashboard")
@login_required
def dashboard():
    if g.user["role"] in ("admin", "hr"):
        return render_template("reports/dashboard_staff.html", cards=services.dashboard_cards())
    emp = g.employee
    today = date.today()
    records = attendance.employee_records(emp["id"], today.year, today.month) if emp else []
    return render_template(
        "reports/dashboard_employee.html", employee=emp, summary=attendance.summarize(records),
        balances=leave.balances(emp["id"], today.year) if emp else [],
        requests=leave.list_requests(emp["id"])[:5] if emp else [],
        payslips=payroll.records_for_employee(emp["id"])[:3] if emp else [], label=lambda r: f"{r['year']}-{r['month']:02d}",
    )


@bp.route("/api/v1/dashboard/charts")
@roles_required("admin", "hr")
def api_charts():
    return jsonify(services.dashboard_charts())


@bp.route("/reports")
@roles_required("admin", "hr")
def index():
    today = date.today()
    return render_template("reports/index.html", periods=payroll.periods(), year=today.year, month=today.month, label=payroll.period_label)


@bp.route("/reports/<name>.<fmt>")
@roles_required("admin", "hr")
def export(name, fmt):
    if fmt not in services.EXPORTERS:
        abort(404)
    today = date.today()
    try:
        title, head, rows = services.build_report(name, request.args.get("year", today.year, type=int), request.args.get("month", today.month, type=int), request.args.get("period_id", type=int))
    except ValidationError as exc:
        flash(str(exc), "error")
        return redirect(url_for("reports.index"))
    mime, fn = services.EXPORTERS[fmt]
    audit.record("report", None, "exported", f"{name}.{fmt}")
    return Response(fn(title, head, rows), mimetype=mime, headers={"Content-Disposition": f"attachment; filename={name}.{fmt}"})


@bp.route("/audit")
@roles_required("admin", "hr")
def audit_log():
    return render_template("reports/audit.html", entries=audit.recent(100, request.args.get("entity") or None))


@bp.route("/notifications")
@roles_required("admin", "hr")
def notification_log():
    rows = query("SELECT * FROM notification_logs ORDER BY id DESC LIMIT 100")
    total = len(rows)
    ok = sum(1 for r in rows if r["status"] == "sent")
    return render_template("reports/notifications.html", rows=rows, ok=ok, total=total)
