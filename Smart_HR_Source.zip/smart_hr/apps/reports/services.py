"""Dashboard aggregates and downloadable reports (CSV / Excel / PDF)."""
import calendar
import csv
import io
from datetime import date, timedelta

from apps.attendance import services as attendance
from apps.core.db import query
from apps.leave_management import services as leave
from apps.payroll import services as payroll
from apps.core.validators import ValidationError


def dashboard_charts():
    dept = query(
        "SELECT COALESCE(d.name, 'Unassigned') AS label, COUNT(e.id) AS value FROM employees e "
        "LEFT JOIN departments d ON d.id = e.department_id WHERE e.employment_status != 'terminated' GROUP BY label ORDER BY value DESC"
    )
    since = (date.today() - timedelta(days=29)).isoformat()
    att = query("SELECT status AS label, COUNT(*) AS value FROM attendance WHERE work_date >= ? GROUP BY status ORDER BY status", (since,))
    lv = query("SELECT status AS label, COUNT(*) AS value FROM leave_requests GROUP BY status ORDER BY status")
    pay = query(
        "SELECT p.year || '-' || printf('%02d', p.month) AS label, ROUND(SUM(r.net), 2) AS value FROM payroll_records r "
        "JOIN payroll_periods p ON p.id = r.period_id GROUP BY p.id ORDER BY p.year, p.month"
    )
    to_list = lambda rows: [{"label": r["label"], "value": r["value"]} for r in rows]
    return {"departments": to_list(dept), "attendance": to_list(att), "leave": to_list(lv), "payroll": to_list(pay)}


def dashboard_cards():
    one = lambda sql, p=(): query(sql, p, one=True)["c"]
    today = date.today().isoformat()
    return {
        "headcount": one("SELECT COUNT(*) AS c FROM employees WHERE employment_status != 'terminated'"),
        "departments": one("SELECT COUNT(*) AS c FROM departments"),
        "present_today": one("SELECT COUNT(*) AS c FROM attendance WHERE work_date = ? AND status IN ('present','late')", (today,)),
        "pending_leave": one("SELECT COUNT(*) AS c FROM leave_requests WHERE status = 'pending'"),
    }


# ---- Reports ----------------------------------------------------------------
def build_report(name, year, month, period_id=None):
    if name == "headcount":
        rows = query(
            "SELECT COALESCE(d.name, 'Unassigned') AS dept, COUNT(e.id) AS c FROM employees e LEFT JOIN departments d ON d.id = e.department_id "
            "WHERE e.employment_status != 'terminated' GROUP BY dept ORDER BY dept"
        )
        return "Headcount by department", ["Department", "Employees"], [[r["dept"], r["c"]] for r in rows]
    if name == "attendance":
        rows = attendance.monthly_report(year, month)
        head = ["Code", "Employee", "Department", "Present", "Late", "Absent", "Half day", "On leave", "Days recorded"]
        data = [[r["employee_code"], r["full_name"], r["department"] or "-", r["present"] or 0, r["late"] or 0, r["absent"] or 0, r["half_day"] or 0, r["on_leave"] or 0, r["days_recorded"]] for r in rows]
        return f"Attendance summary {calendar.month_name[month]} {year}", head, data
    if name == "leave":
        rows = leave.list_requests()
        head = ["Code", "Employee", "Type", "Start", "End", "Days", "Status"]
        return "Leave requests", head, [[r["employee_code"], r["full_name"], r["leave_type"], r["start_date"], r["end_date"], r["days"], r["status"]] for r in rows]
    if name == "payroll":
        period = payroll.get_period(period_id) if period_id else None
        if period is None:
            raise ValidationError("Select a payroll period")
        rows = payroll.records_for_period(period["id"])
        head = ["Code", "Employee", "Gross", "Deductions", "Net", "Payment", "Payslip"]
        data = [[r["employee_code"], r["full_name"], f"{r['gross']:.2f}", f"{r['deductions']:.2f}", f"{r['net']:.2f}", r["payment_status"], "yes" if r["payslip_generated_at"] else "no"] for r in rows]
        return f"Payroll summary {payroll.period_label(period)}", head, data
    raise ValidationError("Unknown report")


def to_csv(head, rows):
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(head)
    for row in rows:
        # neutralise spreadsheet formula injection
        w.writerow([("'" + c) if isinstance(c, str) and c[:1] in "=+-@" else c for c in row])
    return buf.getvalue().encode()


def to_xlsx(title, head, rows):
    from openpyxl import Workbook
    from openpyxl.styles import Font

    wb = Workbook()
    ws = wb.active
    ws.title = title[:31]
    ws.append(head)
    for c in ws[1]:
        c.font = Font(bold=True)
    for row in rows:
        ws.append([("'" + c) if isinstance(c, str) and c[:1] in "=+-@" else c for c in row])
    for i, col in enumerate(ws.columns, 1):
        ws.column_dimensions[ws.cell(1, i).column_letter].width = max(12, max(len(str(c.value or "")) for c in col) + 2)
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def to_pdf(title, head, rows):
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=landscape(A4), title=title)
    styles = getSampleStyleSheet()
    table = Table([head] + [[str(c) for c in r] for r in rows] or [head], repeatRows=1)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1f4e79")), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.3, colors.grey), ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#eef3f8")]),
    ]))
    doc.build([Paragraph(title, styles["Title"]), Spacer(1, 8), table])
    return buf.getvalue()


EXPORTERS = {
    "csv": ("text/csv", lambda t, h, r: to_csv(h, r)),
    "xlsx": ("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", to_xlsx),
    "pdf": ("application/pdf", to_pdf),
}
