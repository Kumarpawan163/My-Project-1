"""Authentication helpers, role-based authorization and CSRF protection."""
import functools
import hmac
import secrets

from flask import abort, g, jsonify, redirect, request, session, url_for

from apps.core.db import query

ROLES = ("admin", "hr", "employee")


def load_current_user():
    g.user = None
    g.employee = None
    uid = session.get("user_id")
    if uid:
        user = query("SELECT * FROM users WHERE id = ? AND is_active = 1", (uid,), one=True)
        if user is None:
            session.clear()
        else:
            g.user = user
            g.employee = query("SELECT * FROM employees WHERE user_id = ?", (uid,), one=True)


def _wants_json():
    return "/api/" in request.path


def login_required(view):
    @functools.wraps(view)
    def wrapped(*args, **kwargs):
        if g.get("user") is None:
            if _wants_json():
                return jsonify(error="authentication required"), 401
            return redirect(url_for("accounts.login", next=request.path))
        return view(*args, **kwargs)

    return wrapped


def roles_required(*roles):
    """Least-privilege decorator: only the listed roles may call the view."""

    def decorator(view):
        @functools.wraps(view)
        @login_required
        def wrapped(*args, **kwargs):
            if g.user["role"] not in roles:
                abort(403)
            return view(*args, **kwargs)

        return wrapped

    return decorator


def csrf_token():
    if "csrf" not in session:
        session["csrf"] = secrets.token_hex(16)
    return session["csrf"]


def check_csrf():
    if request.method in ("POST", "PUT", "PATCH", "DELETE") and not _wants_json():
        sent = request.form.get("csrf_token", "")
        expected = session.get("csrf", "")
        if not expected or not hmac.compare_digest(sent, expected):
            abort(400, "Invalid or missing CSRF token")
