"""Audit trail for sensitive employee, leave, attendance and payroll changes."""
from flask import g

from apps.core.db import execute, query


def record(entity, entity_id, action, details=""):
    actor = g.user["id"] if g.get("user") is not None else None
    execute(
        "INSERT INTO audit_logs (actor_id, entity, entity_id, action, details) VALUES (?, ?, ?, ?, ?)",
        (actor, entity, entity_id, action, details),
    )


def recent(limit=50, entity=None):
    sql = (
        "SELECT a.*, u.email AS actor_email FROM audit_logs a "
        "LEFT JOIN users u ON u.id = a.actor_id"
    )
    params = []
    if entity:
        sql += " WHERE a.entity = ?"
        params.append(entity)
    sql += " ORDER BY a.id DESC LIMIT ?"
    params.append(limit)
    return query(sql, params)
