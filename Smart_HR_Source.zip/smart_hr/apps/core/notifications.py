"""Email notifications with templates and a delivery log.

EMAIL_BACKEND=console writes the message to the application log (default, safe for demos).
EMAIL_BACKEND=smtp sends through SMTP_HOST using the SMTP_* settings.
Every attempt is recorded in notification_logs as 'sent' or 'failed'.
"""
import logging
import smtplib
from email.message import EmailMessage

from flask import current_app

from apps.core.db import execute

log = logging.getLogger("smart_hr.notifications")

TEMPLATES = {
    "leave_decision": (
        "Your leave request was {status}",
        "Hello {name},\n\nYour {leave_type} request ({start} to {end}) was {status}.\n"
        "Reviewer remarks: {remarks}\n\nRegards,\nHR Team",
    ),
    "attendance_correction": (
        "Attendance corrected for {date}",
        "Hello {name},\n\nHR corrected your attendance for {date} to '{status}'.\nReason: {reason}\n\nRegards,\nHR Team",
    ),
    "payslip_ready": (
        "Your payslip for {period} is available",
        "Hello {name},\n\nYour payslip for {period} is ready. Sign in to download it.\n\nRegards,\nHR Team",
    ),
}


def send(template, recipient, **context):
    subject_tpl, body_tpl = TEMPLATES[template]
    subject = subject_tpl.format(**context)
    body = body_tpl.format(**context)
    status, error = "sent", ""
    try:
        backend = current_app.config["EMAIL_BACKEND"]
        if backend == "smtp":
            _send_smtp(recipient, subject, body)
        else:
            log.info("email.console to=%s subject=%s", recipient, subject)
    except Exception as exc:  # delivery must never break the business workflow
        status, error = "failed", str(exc)[:300]
        log.warning("email.failed to=%s template=%s error=%s", recipient, template, error)
    execute(
        "INSERT INTO notification_logs (recipient, subject, template, status, error) VALUES (?, ?, ?, ?, ?)",
        (recipient, subject, template, status, error),
    )
    return status == "sent"


def _send_smtp(recipient, subject, body):
    cfg = current_app.config
    msg = EmailMessage()
    msg["From"], msg["To"], msg["Subject"] = cfg["DEFAULT_FROM_EMAIL"], recipient, subject
    msg.set_content(body)
    with smtplib.SMTP(cfg["SMTP_HOST"], cfg["SMTP_PORT"], timeout=10) as smtp:
        smtp.starttls()
        if cfg["SMTP_USER"]:
            smtp.login(cfg["SMTP_USER"], cfg["SMTP_PASSWORD"])
        smtp.send_message(msg)
