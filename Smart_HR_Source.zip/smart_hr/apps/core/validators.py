"""Server-side validation helpers shared by the apps."""
import re
from datetime import date, datetime

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


class ValidationError(Exception):
    def __init__(self, errors):
        if isinstance(errors, str):
            errors = [errors]
        self.errors = errors
        super().__init__("; ".join(errors))


def parse_date(value, label="date"):
    try:
        return datetime.strptime((value or "").strip(), "%Y-%m-%d").date()
    except ValueError:
        raise ValidationError(f"{label} must be a valid date (YYYY-MM-DD)")


def require(value, label):
    value = (value or "").strip()
    if not value:
        raise ValidationError(f"{label} is required")
    return value


def valid_email(value):
    value = require(value, "Email").lower()
    if not EMAIL_RE.match(value):
        raise ValidationError("Email is not valid")
    return value


def working_days(start: date, end: date):
    """Number of Monday-Friday days in the inclusive range."""
    from datetime import timedelta

    days, cur = 0, start
    while cur <= end:
        if cur.weekday() < 5:
            days += 1
        cur += timedelta(days=1)
    return days
