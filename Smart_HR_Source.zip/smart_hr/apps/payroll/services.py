"""Payroll: salary components, payroll periods/records and controlled payslips."""
import calendar
import io

from apps.core import audit, notifications
from apps.core.db import execute, get_db, query
from apps.core.validators import ValidationError, require
from apps.leave_management.services import PermissionDenied

STAFF = ("admin", "hr")


def components(employee_id):
    return query("SELECT * FROM salary_components WHERE employee_id = ? ORDER BY kind DESC, name", (employee_id,))


def set_component(employee_id, name, kind, amount):
    name = require(name, "Component name")
    if kind not in ("earning", "deduction"):
        raise ValidationError("Kind must be earning or deduction")
    try:
        amount = round(float(amount), 2)
    except (TypeError, ValueError):
        raise ValidationError("Amount must be a number")
    if amount < 0:
        raise ValidationError("Amount cannot be negative")
    if query("SELECT 1 FROM employees WHERE id = ?", (employee_id,), one=True) is None:
        raise ValidationError("Employee not found")
    execute(
        "INSERT INTO salary_components (employee_id, name, kind, amount) VALUES (?, ?, ?, ?) "
        "ON CONFLICT(employee_id, name) DO UPDATE SET kind = excluded.kind, amount = excluded.amount",
        (employee_id, name, kind, amount),
    )
    audit.record("salary_component", employee_id, "set", f"{name} ({kind}) = {amount:.2f}")


def periods():
    return query(
        "SELECT p.*, COUNT(r.id) AS records, COALESCE(SUM(r.gross),0) AS gross, COALESCE(SUM(r.deductions),0) AS deductions, "
        "COALESCE(SUM(r.net),0) AS net, COALESCE(SUM(r.payment_status='paid'),0) AS paid, "
        "COALESCE(SUM(r.payslip_generated_at IS NOT NULL),0) AS payslips "
        "FROM payroll_periods p LEFT JOIN payroll_records r ON r.period_id = p.id GROUP BY p.id ORDER BY p.year DESC, p.month DESC"
    )


def get_period(period_id):
    return query("SELECT * FROM payroll_periods WHERE id = ?", (period_id,), one=True)


def period_label(period):
    return f"{calendar.month_name[period['month']]} {period['year']}"


def create_period(year, month):
    if not (1 <= month <= 12) or not (2000 <= year <= 2100):
        raise ValidationError("Enter a valid year and month")
    if query("SELECT 1 FROM payroll_periods WHERE year = ? AND month = ?", (year, month), one=True):
        raise ValidationError("This payroll period already exists")
    pid = execute("INSERT INTO payroll_periods (year, month) VALUES (?, ?)", (year, month))
    audit.record("payroll_period", pid, "created", f"{year}-{month:02d}")
    return pid


def generate_records(period_id):
    period = get_period(period_id)
    if period is None:
        raise ValidationError("Payroll period not found")
    if period["status"] == "closed":
        raise ValidationError("Period is closed")
    db = get_db()
    created = skipped = 0
    for emp in query("SELECT id FROM employees WHERE employment_status != 'terminated'"):
        comps = components(emp["id"])
        gross = sum(c["amount"] for c in comps if c["kind"] == "earning")
        ded = sum(c["amount"] for c in comps if c["kind"] == "deduction")
        if gross <= 0:
            skipped += 1
            continue
        if ded > gross:
            skipped += 1
            continue
        existing = query("SELECT * FROM payroll_records WHERE period_id = ? AND employee_id = ?", (period_id, emp["id"]), one=True)
        if existing and existing["payment_status"] == "paid":
            continue
        db.execute(
            "INSERT INTO payroll_records (period_id, employee_id, gross, deductions, net) VALUES (?, ?, ?, ?, ?) "
            "ON CONFLICT(period_id, employee_id) DO UPDATE SET gross = excluded.gross, deductions = excluded.deductions, net = excluded.net",
            (period_id, emp["id"], gross, ded, gross - ded),
        )
        created += 1
    db.commit()
    audit.record("payroll_period", period_id, "records_generated", f"records={created}, skipped={skipped}")
    return created, skipped


def records_for_period(period_id):
    return query(
        "SELECT r.*, e.full_name, e.employee_code FROM payroll_records r JOIN employees e ON e.id = r.employee_id "
        "WHERE r.period_id = ? ORDER BY e.full_name",
        (period_id,),
    )


def records_for_employee(employee_id):
    return query(
        "SELECT r.*, p.year, p.month FROM payroll_records r JOIN payroll_periods p ON p.id = r.period_id "
        "WHERE r.employee_id = ? ORDER BY p.year DESC, p.month DESC",
        (employee_id,),
    )


def get_record(record_id):
    return query(
        "SELECT r.*, p.year, p.month, e.full_name, e.employee_code, e.job_title, e.user_id AS owner_user_id, u.email, d.name AS department "
        "FROM payroll_records r JOIN payroll_periods p ON p.id = r.period_id JOIN employees e ON e.id = r.employee_id "
        "JOIN users u ON u.id = e.user_id LEFT JOIN departments d ON d.id = e.department_id WHERE r.id = ?",
        (record_id,),
        one=True,
    )


def mark_paid(record_id, actor):
    if actor["role"] != "admin":
        raise PermissionDenied("Only Admin can mark payroll as paid")
    rec = get_record(record_id)
    if rec is None:
        raise ValidationError("Payroll record not found")
    execute("UPDATE payroll_records SET payment_status = 'paid' WHERE id = ?", (record_id,))
    audit.record("payroll_record", record_id, "marked_paid", f"{rec['employee_code']} {rec['year']}-{rec['month']:02d}")


def generate_payslip(record_id, actor):
    if actor["role"] not in STAFF:
        raise PermissionDenied("Only HR or Admin can generate payslips")
    rec = get_record(record_id)
    if rec is None:
        raise ValidationError("Payroll record not found")
    execute("UPDATE payroll_records SET payslip_generated_at = datetime('now') WHERE id = ?", (record_id,))
    audit.record("payroll_record", record_id, "payslip_generated", rec["employee_code"])
    label = f"{calendar.month_name[rec['month']]} {rec['year']}"
    notifications.send("payslip_ready", rec["email"], name=rec["full_name"], period=label)


def can_download(record, user):
    if user["role"] in STAFF:
        return True
    return record["owner_user_id"] == user["id"] and record["payslip_generated_at"] is not None


def payslip_pdf(record_id):
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

    rec = get_record(record_id)
    comps = components(rec["employee_id"])
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, title=f"Payslip {rec['employee_code']}")
    styles = getSampleStyleSheet()
    label = f"{calendar.month_name[rec['month']]} {rec['year']}"
    story = [
        Paragraph("Payslip", styles["Title"]),
        Paragraph(f"{label} (synthetic demo data)", styles["Normal"]),
        Spacer(1, 12),
        Paragraph(f"<b>{rec['full_name']}</b> &mdash; {rec['employee_code']}<br/>{rec['job_title']} | {rec['department'] or '-'}", styles["Normal"]),
        Spacer(1, 12),
    ]
    rows = [["Component", "Type", "Amount"]]
    rows += [[c["name"], c["kind"].title(), f"{c['amount']:,.2f}"] for c in comps]
    rows += [["Gross", "", f"{rec['gross']:,.2f}"], ["Deductions", "", f"{rec['deductions']:,.2f}"], ["Net pay", "", f"{rec['net']:,.2f}"]]
    table = Table(rows, colWidths=[250, 100, 110])
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1f4e79")), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.grey), ("ALIGN", (2, 0), (2, -1), "RIGHT"),
        ("FONTNAME", (0, -1), (-1, -1), "Helvetica-Bold"),
    ]))
    story.append(table)
    doc.build(story)
    return buf.getvalue()


def kpis():
    total = query("SELECT COUNT(*) AS c FROM payroll_records", one=True)["c"]
    slips = query("SELECT COUNT(*) AS c FROM payroll_records WHERE payslip_generated_at IS NOT NULL", one=True)["c"]
    eligible = query("SELECT COUNT(DISTINCT employee_id) AS c FROM salary_components WHERE kind = 'earning'", one=True)["c"]
    active = query("SELECT COUNT(*) AS c FROM employees WHERE employment_status != 'terminated'", one=True)["c"]
    return {
        "record_completeness": (eligible / active) if active else 0.0,
        "payslip_success_rate": (slips / total) if total else 0.0,
    }
