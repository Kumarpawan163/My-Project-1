from datetime import date

from flask import Blueprint, Response, abort, flash, g, redirect, render_template, request, url_for

from apps.core.security import login_required, roles_required
from apps.core.validators import ValidationError
from apps.employees.services import get_employee
from apps.leave_management.services import PermissionDenied
from apps.payroll import services

bp = Blueprint("payroll", __name__, url_prefix="/payroll")
STAFF = ("admin", "hr")


@bp.route("/", methods=["GET", "POST"])
@roles_required(*STAFF)
def index():
    if request.method == "POST":
        try:
            pid = services.create_period(request.form.get("year", type=int) or 0, request.form.get("month", type=int) or 0)
            flash("Payroll period created.", "success")
            return redirect(url_for("payroll.period", period_id=pid))
        except ValidationError as exc:
            flash(str(exc), "error")
    today = date.today()
    return render_template("payroll/index.html", periods=services.periods(), label=services.period_label, year=today.year, month=today.month)


@bp.route("/period/<int:period_id>")
@roles_required(*STAFF)
def period(period_id):
    p = services.get_period(period_id)
    if p is None:
        abort(404)
    return render_template("payroll/period.html", period=p, label=services.period_label(p), records=services.records_for_period(period_id))


@bp.route("/period/<int:period_id>/generate", methods=["POST"])
@roles_required(*STAFF)
def generate(period_id):
    try:
        created, skipped = services.generate_records(period_id)
        flash(f"Generated {created} payroll record(s); {skipped} employee(s) skipped (no valid salary components).", "success")
    except ValidationError as exc:
        flash(str(exc), "error")
    return redirect(url_for("payroll.period", period_id=period_id))


@bp.route("/employee/<int:employee_id>", methods=["GET", "POST"])
@roles_required(*STAFF)
def salary(employee_id):
    emp = get_employee(employee_id)
    if emp is None:
        abort(404)
    if request.method == "POST":
        try:
            services.set_component(employee_id, request.form.get("name"), request.form.get("kind"), request.form.get("amount"))
            flash("Salary component saved.", "success")
            return redirect(url_for("payroll.salary", employee_id=employee_id))
        except ValidationError as exc:
            flash(str(exc), "error")
    return render_template("payroll/salary.html", employee=emp, components=services.components(employee_id))


@bp.route("/me")
@login_required
def mine():
    if g.employee is None:
        abort(404)
    return render_template("payroll/mine.html", records=services.records_for_employee(g.employee["id"]))


@bp.route("/record/<int:record_id>/<action>", methods=["POST"])
@login_required
def record_action(record_id, action):
    try:
        if action == "payslip":
            services.generate_payslip(record_id, g.user)
            flash("Payslip generated and employee notified.", "success")
        elif action == "paid":
            services.mark_paid(record_id, g.user)
            flash("Marked as paid.", "success")
        else:
            abort(404)
    except PermissionDenied:
        abort(403)
    except ValidationError as exc:
        flash(str(exc), "error")
    rec = services.get_record(record_id)
    return redirect(url_for("payroll.period", period_id=services.get_period(rec["period_id"])["id"]) if rec else url_for("payroll.index"))


@bp.route("/record/<int:record_id>/download")
@login_required
def download(record_id):
    rec = services.get_record(record_id)
    if rec is None:
        abort(404)
    if not services.can_download(rec, g.user):
        abort(403)
    name = f"payslip_{rec['employee_code']}_{rec['year']}-{rec['month']:02d}.pdf"
    return Response(services.payslip_pdf(record_id), mimetype="application/pdf", headers={"Content-Disposition": f"attachment; filename={name}"})
