"""Attendance rules: check-in/out, corrections and monthly summaries."""
import calendar
from datetime import datetime

from flask import current_app

from apps.core import audit, notifications
from apps.core.db import execute, query
from apps.core.validators import ValidationError, parse_date, require

STATUSES = ("present", "late", "absent", "half_day", "on_leave")


def _hhmm(value, label):
    value = (value or "").strip()
    if not value:
        return None
    try:
        return datetime.strptime(value, "%H:%M").strftime("%H:%M")
    except ValueError:
        raise ValidationError(f"{label} must be a time (HH:MM)")


def check_in(employee, now=None):
    now = now or datetime.now()
    today = now.strftime("%Y-%m-%d")
    if employee["employment_status"] == "terminated":
        raise ValidationError("Terminated employees cannot record attendance")
    if query("SELECT 1 FROM attendance WHERE employee_id = ? AND work_date = ?", (employee["id"], today), one=True):
        raise ValidationError("Attendance is already recorded for today")
    status = "late" if now.strftime("%H:%M") > current_app.config["LATE_AFTER"] else "present"
    rid = execute(
        "INSERT INTO attendance (employee_id, work_date, check_in, status) VALUES (?, ?, ?, ?)",
        (employee["id"], today, now.strftime("%H:%M"), status),
    )
    return rid, status


def check_out(employee, now=None):
    now = now or datetime.now()
    today = now.strftime("%Y-%m-%d")
    row = query("SELECT * FROM attendance WHERE employee_id = ? AND work_date = ?", (employee["id"], today), one=True)
    if row is None or not row["check_in"]:
        raise ValidationError("You must check in before checking out")
    if row["check_out"]:
        raise ValidationError("You have already checked out today")
    out = now.strftime("%H:%M")
    if out <= row["check_in"]:
        raise ValidationError("Check-out must be after check-in")
    execute("UPDATE attendance SET check_out = ? WHERE id = ?", (out, row["id"]))
    return row["id"]


def correct(employee_id, work_date, status, check_in_time, check_out_time, reason, actor_user):
    """HR/Admin correction. A written reason is mandatory and the change is audited."""
    if actor_user["role"] not in ("admin", "hr"):
        raise ValidationError("Only HR or Admin can correct attendance")
    reason = require(reason, "Correction reason")
    day = parse_date(work_date, "Work date")
    if status not in STATUSES:
        raise ValidationError("Invalid attendance status")
    cin, cout = _hhmm(check_in_time, "Check-in"), _hhmm(check_out_time, "Check-out")
    if cin and cout and cout <= cin:
        raise ValidationError("Check-out must be after check-in")
    emp = query("SELECT e.*, u.email FROM employees e JOIN users u ON u.id = e.user_id WHERE e.id = ?", (employee_id,), one=True)
    if emp is None:
        raise ValidationError("Employee not found")
    existing = query("SELECT * FROM attendance WHERE employee_id = ? AND work_date = ?", (employee_id, day.isoformat()), one=True)
    if existing:
        execute(
            "UPDATE attendance SET status=?, check_in=?, check_out=?, corrected_by=?, correction_reason=? WHERE id=?",
            (status, cin, cout, actor_user["id"], reason, existing["id"]),
        )
        rid = existing["id"]
    else:
        rid = execute(
            "INSERT INTO attendance (employee_id, work_date, check_in, check_out, status, corrected_by, correction_reason) VALUES (?, ?, ?, ?, ?, ?, ?)",
            (employee_id, day.isoformat(), cin, cout, status, actor_user["id"], reason),
        )
    audit.record("attendance", rid, "corrected", f"{day} -> {status}; reason={reason}")
    notifications.send("attendance_correction", emp["email"], name=emp["full_name"], date=day.isoformat(), status=status, reason=reason)
    return rid


def month_bounds(year, month):
    last = calendar.monthrange(year, month)[1]
    return f"{year:04d}-{month:02d}-01", f"{year:04d}-{month:02d}-{last:02d}"


def employee_records(employee_id, year, month):
    start, end = month_bounds(year, month)
    return query(
        "SELECT * FROM attendance WHERE employee_id = ? AND work_date BETWEEN ? AND ? ORDER BY work_date",
        (employee_id, start, end),
    )


def summarize(records):
    summary = {s: 0 for s in STATUSES}
    for r in records:
        summary[r["status"]] += 1
    summary["days_recorded"] = len(records)
    return summary


def monthly_report(year, month):
    start, end = month_bounds(year, month)
    return query(
        "SELECT e.id, e.employee_code, e.full_name, d.name AS department, "
        "SUM(a.status='present') AS present, SUM(a.status='late') AS late, SUM(a.status='absent') AS absent, "
        "SUM(a.status='half_day') AS half_day, SUM(a.status='on_leave') AS on_leave, COUNT(a.id) AS days_recorded "
        "FROM employees e LEFT JOIN departments d ON d.id = e.department_id "
        "LEFT JOIN attendance a ON a.employee_id = e.id AND a.work_date BETWEEN ? AND ? "
        "WHERE e.employment_status != 'terminated' GROUP BY e.id ORDER BY e.full_name",
        (start, end),
    )
