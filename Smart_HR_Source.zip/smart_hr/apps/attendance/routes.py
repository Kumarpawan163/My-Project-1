from datetime import date

from flask import Blueprint, abort, flash, g, redirect, render_template, request, url_for

from apps.attendance import services
from apps.core.security import login_required, roles_required
from apps.core.validators import ValidationError
from apps.employees.services import get_employee, search_employees

bp = Blueprint("attendance", __name__, url_prefix="/attendance")


def _period():
    today = date.today()
    return request.args.get("year", today.year, type=int), request.args.get("month", today.month, type=int)


@bp.route("/")
@login_required
def mine():
    if g.employee is None:
        abort(404)
    year, month = _period()
    records = services.employee_records(g.employee["id"], year, month)
    today_row = next((r for r in records if r["work_date"] == date.today().isoformat()), None)
    return render_template("attendance/mine.html", records=records, summary=services.summarize(records), year=year, month=month, today_row=today_row)


@bp.route("/check-in", methods=["POST"])
@login_required
def check_in():
    if g.employee is None:
        abort(403)
    try:
        _, status = services.check_in(g.employee)
        flash(f"Checked in ({status}).", "success")
    except ValidationError as exc:
        flash(str(exc), "error")
    return redirect(url_for("attendance.mine"))


@bp.route("/check-out", methods=["POST"])
@login_required
def check_out():
    if g.employee is None:
        abort(403)
    try:
        services.check_out(g.employee)
        flash("Checked out.", "success")
    except ValidationError as exc:
        flash(str(exc), "error")
    return redirect(url_for("attendance.mine"))


@bp.route("/employee/<int:employee_id>", methods=["GET", "POST"])
@roles_required("admin", "hr")
def manage(employee_id):
    emp = get_employee(employee_id)
    if emp is None:
        abort(404)
    if request.method == "POST":
        try:
            services.correct(
                employee_id, request.form.get("work_date"), request.form.get("status"),
                request.form.get("check_in"), request.form.get("check_out"), request.form.get("reason"), g.user,
            )
            flash("Attendance corrected and employee notified.", "success")
            return redirect(url_for("attendance.manage", employee_id=employee_id))
        except ValidationError as exc:
            flash(str(exc), "error")
    year, month = _period()
    records = services.employee_records(employee_id, year, month)
    return render_template("attendance/manage.html", employee=emp, records=records, summary=services.summarize(records), year=year, month=month, statuses=services.STATUSES, today=date.today().isoformat())


@bp.route("/monthly")
@roles_required("admin", "hr")
def monthly():
    year, month = _period()
    return render_template("attendance/monthly.html", rows=services.monthly_report(year, month), year=year, month=month)
