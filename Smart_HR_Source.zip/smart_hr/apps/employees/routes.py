from flask import Blueprint, abort, current_app, flash, g, jsonify, redirect, render_template, request, url_for

from apps.core import audit
from apps.core.security import login_required, roles_required
from apps.core.validators import ValidationError
from apps.employees import services

bp = Blueprint("employees", __name__)
STAFF = ("admin", "hr")


@bp.route("/employees")
@roles_required(*STAFF)
def index():
    page = request.args.get("page", 1, type=int)
    size = current_app.config["PAGE_SIZE"]
    dept = request.args.get("department", type=int)
    rows, total = services.search_employees(request.args.get("q", "").strip(), dept, request.args.get("status", ""), page, size)
    pages = max(1, -(-total // size))
    return render_template(
        "employees/list.html", employees=rows, total=total, page=page, pages=pages,
        departments=services.list_departments(), q=request.args.get("q", ""), dept=dept, status=request.args.get("status", ""),
    )


@bp.route("/employees/new", methods=["GET", "POST"])
@roles_required(*STAFF)
def create():
    if request.method == "POST":
        try:
            eid = services.create_employee(request.form)
            flash("Employee created.", "success")
            return redirect(url_for("employees.detail", employee_id=eid))
        except ValidationError as exc:
            for e in exc.errors:
                flash(e, "error")
    return render_template("employees/form.html", employee=None, form=request.form, departments=services.list_departments(), statuses=services.STATUSES)


@bp.route("/employees/<int:employee_id>")
@login_required
def detail(employee_id):
    emp = services.get_employee(employee_id)
    if emp is None:
        abort(404)
    if g.user["role"] == "employee" and (g.employee is None or g.employee["id"] != employee_id):
        abort(403)
    history = audit.recent(20, "employee") if g.user["role"] in STAFF else []
    history = [h for h in history if h["entity_id"] == employee_id]
    return render_template("employees/detail.html", employee=emp, completeness=services.completeness(emp), history=history)


@bp.route("/employees/<int:employee_id>/edit", methods=["GET", "POST"])
@roles_required(*STAFF)
def edit(employee_id):
    emp = services.get_employee(employee_id)
    if emp is None:
        abort(404)
    if request.method == "POST":
        try:
            services.update_employee(employee_id, request.form)
            flash("Employee updated.", "success")
            return redirect(url_for("employees.detail", employee_id=employee_id))
        except ValidationError as exc:
            for e in exc.errors:
                flash(e, "error")
    return render_template("employees/form.html", employee=emp, form=request.form or emp, departments=services.list_departments(), statuses=services.STATUSES)


@bp.route("/departments", methods=["GET", "POST"])
@roles_required(*STAFF)
def departments():
    if request.method == "POST":
        try:
            services.create_department(request.form.get("name"), request.form.get("description", ""))
            flash("Department added.", "success")
            return redirect(url_for("employees.departments"))
        except ValidationError as exc:
            for e in exc.errors:
                flash(e, "error")
    return render_template("employees/departments.html", departments=services.list_departments())


# ---- JSON API -------------------------------------------------------------
@bp.route("/api/v1/employees")
@roles_required(*STAFF)
def api_list():
    rows, total = services.search_employees(request.args.get("q", ""), request.args.get("department", type=int), request.args.get("status", ""), request.args.get("page", 1, type=int), 20)
    return jsonify(total=total, results=[{k: r[k] for k in ("id", "employee_code", "full_name", "job_title", "department", "employment_status", "email")} for r in rows])


@bp.route("/api/v1/me")
@login_required
def api_me():
    emp = g.employee
    return jsonify(email=g.user["email"], role=g.user["role"], employee_code=emp["employee_code"] if emp else None, full_name=emp["full_name"] if emp else None)
