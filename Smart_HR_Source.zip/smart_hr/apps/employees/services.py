"""Employee and department business logic and data access."""
from apps.accounts.services import create_user
from apps.core import audit
from apps.core.db import execute, get_db, query
from apps.core.validators import ValidationError, parse_date, require

STATUSES = ("active", "on_leave", "terminated")


def list_departments():
    return query(
        "SELECT d.*, (SELECT COUNT(*) FROM employees e WHERE e.department_id = d.id AND e.employment_status != 'terminated') AS headcount "
        "FROM departments d ORDER BY d.name"
    )


def create_department(name, description=""):
    name = require(name, "Department name")
    if query("SELECT 1 FROM departments WHERE lower(name) = lower(?)", (name,), one=True):
        raise ValidationError("Department already exists")
    did = execute("INSERT INTO departments (name, description) VALUES (?, ?)", (name, description.strip()))
    audit.record("department", did, "created", name)
    return did


def search_employees(q="", department_id=None, status="", page=1, page_size=8):
    where, params = ["1=1"], []
    if q:
        where.append("(e.full_name LIKE ? OR e.employee_code LIKE ? OR u.email LIKE ?)")
        params += [f"%{q}%"] * 3
    if department_id:
        where.append("e.department_id = ?")
        params.append(department_id)
    if status:
        where.append("e.employment_status = ?")
        params.append(status)
    clause = " AND ".join(where)
    base = "FROM employees e JOIN users u ON u.id = e.user_id LEFT JOIN departments d ON d.id = e.department_id WHERE " + clause
    total = query(f"SELECT COUNT(*) AS c {base}", params, one=True)["c"]
    page = max(1, page)
    rows = query(
        f"SELECT e.*, u.email, u.role, d.name AS department {base} ORDER BY e.full_name LIMIT ? OFFSET ?",
        params + [page_size, (page - 1) * page_size],
    )
    return rows, total


def get_employee(employee_id):
    return query(
        "SELECT e.*, u.email, u.role, d.name AS department FROM employees e JOIN users u ON u.id = e.user_id "
        "LEFT JOIN departments d ON d.id = e.department_id WHERE e.id = ?",
        (employee_id,),
        one=True,
    )


def _next_code():
    row = query("SELECT COUNT(*) AS c FROM employees", one=True)
    return f"EMP{row['c'] + 1:04d}"


def _validated(form):
    name = require(form.get("full_name"), "Full name")
    parse_date(form.get("joining_date"), "Joining date")
    status = form.get("employment_status", "active")
    if status not in STATUSES:
        raise ValidationError("Invalid employment status")
    dept = form.get("department_id") or None
    if dept and not query("SELECT 1 FROM departments WHERE id = ?", (dept,), one=True):
        raise ValidationError("Department does not exist")
    return name, status, dept


def create_employee(form):
    name, status, dept = _validated(form)
    role = form.get("role", "employee")
    uid = create_user(form.get("email"), form.get("password"), role)
    eid = execute(
        "INSERT INTO employees (user_id, employee_code, full_name, phone, job_title, department_id, employment_status, joining_date) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        (uid, _next_code(), name, form.get("phone", "").strip(), form.get("job_title", "").strip(), dept, status, form["joining_date"]),
    )
    audit.record("employee", eid, "created", f"name={name}")
    return eid


def update_employee(employee_id, form):
    current = get_employee(employee_id)
    if current is None:
        raise ValidationError("Employee not found")
    name, status, dept = _validated(form)
    execute(
        "UPDATE employees SET full_name=?, phone=?, job_title=?, department_id=?, employment_status=?, joining_date=? WHERE id=?",
        (name, form.get("phone", "").strip(), form.get("job_title", "").strip(), dept, status, form["joining_date"], employee_id),
    )
    if status == "terminated":
        execute("UPDATE users SET is_active = 0 WHERE id = ?", (current["user_id"],))
    changes = []
    for field, new in (("department_id", dept), ("employment_status", status), ("job_title", form.get("job_title", "").strip())):
        old = current[field]
        if str(old or "") != str(new or ""):
            changes.append(f"{field}: {old} -> {new}")
    audit.record("employee", employee_id, "updated", "; ".join(changes) or "profile details")


def completeness(employee):
    """Share of profile fields filled in (used by the profile-completeness KPI)."""
    fields = ["full_name", "phone", "job_title", "department_id", "joining_date"]
    return sum(1 for f in fields if employee[f]) / len(fields)
