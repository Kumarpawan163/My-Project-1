"""Leave validation, approval state machine, permissions and side-effects."""
from datetime import date, timedelta

import pytest

from apps.core.db import query
from apps.core.validators import ValidationError
from apps.leave_management import services
from apps.leave_management.services import PermissionDenied
from tests.conftest import emp_id


def u(email):
    return query("SELECT * FROM users WHERE email = ?", (email,), one=True)


def emp(email):
    return query("SELECT e.* FROM employees e JOIN users u ON u.id = e.user_id WHERE u.email = ?", (email,), one=True)


def monday_after(days):
    d = date.today() + timedelta(days=days)
    while d.weekday() != 0:
        d += timedelta(days=1)
    return d


def apply_for(email="hr@demo.example", start=None, end=None, type_id=1, reason="Trip"):
    start = start or monday_after(60)
    end = end or start + timedelta(days=1)
    return services.apply(emp(email), u(email), type_id, start.isoformat(), end.isoformat(), reason)


def test_apply_counts_only_working_days(ctx):
    start = monday_after(90)
    rid = apply_for(start=start, end=start + timedelta(days=6))  # Mon..Sun
    assert services.get_request(rid)["days"] == 5


@pytest.mark.parametrize("kwargs,msg", [
    ({"start": date.today() - timedelta(days=3), "end": date.today()}, "past"),
    ({"reason": " "}, "Reason"),
    ({"type_id": 99}, "valid leave type"),
])
def test_apply_validation(ctx, kwargs, msg):
    with pytest.raises(ValidationError, match=msg):
        apply_for(**kwargs)


def test_end_before_start_rejected(ctx):
    s = monday_after(40)
    with pytest.raises(ValidationError, match="End date"):
        apply_for(start=s, end=s - timedelta(days=1))


def test_weekend_only_range_rejected(ctx):
    sat = monday_after(50) - timedelta(days=2)
    with pytest.raises(ValidationError, match="no working days"):
        apply_for(start=sat, end=sat + timedelta(days=1))


def test_overlap_rejected(ctx):
    s = monday_after(70)
    apply_for(start=s, end=s + timedelta(days=2))
    with pytest.raises(ValidationError, match="overlaps"):
        apply_for(start=s + timedelta(days=2), end=s + timedelta(days=4))


def test_insufficient_balance_rejected(ctx):
    s = monday_after(100)
    with pytest.raises(ValidationError, match="Insufficient"):
        apply_for(start=s, end=s + timedelta(days=13), type_id=3)  # Casual allows 6, request is 10 working days


def test_submit_creates_history(ctx):
    rid = apply_for()
    h = services.history(rid)
    assert [x["to_status"] for x in h] == ["pending"]


def test_hr_approves_and_attendance_marked_on_leave(ctx):
    s = monday_after(30)
    rid = apply_for("employee@demo.example", s, s + timedelta(days=1))
    services.transition(rid, "approved", u("hr@demo.example"), "ok")
    assert services.get_request(rid)["status"] == "approved"
    n = query("SELECT COUNT(*) AS c FROM attendance WHERE status='on_leave' AND work_date IN (?, ?)", (s.isoformat(), (s + timedelta(days=1)).isoformat()), one=True)["c"]
    assert n >= 2
    assert query("SELECT 1 FROM notification_logs WHERE template='leave_decision' AND recipient='employee@demo.example'", one=True)


def test_cancel_after_approval_removes_on_leave_rows(ctx):
    s = monday_after(31)
    rid = apply_for("employee@demo.example", s, s)
    services.transition(rid, "approved", u("hr@demo.example"))
    services.transition(rid, "cancelled", u("hr@demo.example"), "Plans changed")
    assert query("SELECT COUNT(*) AS c FROM attendance WHERE status='on_leave' AND work_date = ? AND employee_id = ?", (s.isoformat(), emp("employee@demo.example")["id"]), one=True)["c"] == 0


def test_rejection_requires_remarks(ctx):
    rid = apply_for("employee@demo.example")
    with pytest.raises(ValidationError, match="Remarks"):
        services.transition(rid, "rejected", u("hr@demo.example"), " ")
    services.transition(rid, "rejected", u("hr@demo.example"), "Busy period")
    assert services.get_request(rid)["remarks"] == "Busy period"


@pytest.mark.parametrize("path", [("rejected", "approved"), ("cancelled", "approved"), ("approved", "rejected"), ("approved", "pending")])
def test_invalid_state_transitions_blocked(ctx, path):
    rid = apply_for("employee@demo.example")
    first, second = path
    services.transition(rid, "approved" if first == "approved" else first, u("hr@demo.example"), "x" if first == "rejected" else "")
    if first == "cancelled":
        pass
    with pytest.raises(ValidationError, match="Invalid transition"):
        services.transition(rid, second, u("hr@demo.example"), "x")


def test_cannot_decide_own_request(ctx):
    rid = apply_for("hr@demo.example")
    with pytest.raises(PermissionDenied):
        services.transition(rid, "approved", u("hr@demo.example"))


def test_employee_cannot_approve(ctx):
    rid = apply_for("hr@demo.example")
    with pytest.raises(PermissionDenied):
        services.transition(rid, "approved", u("employee@demo.example"))


def test_owner_can_cancel_only_pending(ctx):
    rid = apply_for("employee@demo.example")
    services.transition(rid, "cancelled", u("employee@demo.example"))
    rid2 = apply_for("employee@demo.example", monday_after(120))
    services.transition(rid2, "approved", u("hr@demo.example"))
    with pytest.raises(PermissionDenied):
        services.transition(rid2, "cancelled", u("employee@demo.example"))


def test_cancelled_request_frees_balance_and_dates(ctx):
    s = monday_after(45)
    rid = apply_for("employee@demo.example", s, s)
    services.transition(rid, "cancelled", u("employee@demo.example"))
    apply_for("employee@demo.example", s, s)  # overlap no longer applies


def test_http_employee_cannot_approve(app, login):
    emp_s = login("emp")
    pending = query_one(app, "SELECT id FROM leave_requests WHERE status='pending' LIMIT 1")
    assert emp_s.post(f"/leave/{pending}/approve").status_code == 403


def test_http_employee_cannot_view_others_request(app, login):
    other = query_one(app, "SELECT r.id FROM leave_requests r JOIN employees e ON e.id = r.employee_id JOIN users u ON u.id = e.user_id WHERE u.email != 'employee@demo.example' LIMIT 1")
    assert login("emp").get(f"/leave/{other}").status_code == 403


def test_http_hr_approval_flow(app, login):
    pending = query_one(app, "SELECT r.id FROM leave_requests r JOIN employees e ON e.id = r.employee_id JOIN users u ON u.id = e.user_id WHERE r.status='pending' AND u.email='employee@demo.example'")
    hr = login("hr")
    resp = hr.post(f"/leave/{pending}/approve", {"remarks": "Fine"}, follow_redirects=True)
    assert resp.status_code == 200 and b"approved" in resp.data


def test_turnaround_kpi_positive(ctx):
    k = services.kpis()
    assert k["avg_turnaround_hours"] > 0 and k["pending"] >= 1


def query_one(app, sql):
    with app.app_context():
        return query(sql, one=True)[0]
