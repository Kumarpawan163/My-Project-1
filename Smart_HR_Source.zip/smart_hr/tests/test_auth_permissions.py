"""Authentication, role-based access boundaries, CSRF and error handling."""
from tests.conftest import CREDS, Session, emp_id


def test_login_success_and_failure(app):
    s = Session(app)
    bad = s.login("admin@demo.example", "wrong-password")
    assert bad.status_code == 200 and b"Invalid email or password" in bad.data
    ok = s.login(*CREDS["admin"])
    assert ok.status_code == 302


def test_anonymous_redirected_to_login(app):
    resp = app.test_client().get("/employees")
    assert resp.status_code == 302 and "/login" in resp.headers["Location"]


def test_api_returns_401_json_when_anonymous(app):
    resp = app.test_client().get("/api/v1/employees")
    assert resp.status_code == 401 and resp.get_json()["error"]


def test_login_open_redirect_blocked(app):
    s = Session(app)
    resp = s.c.post("/login?next=//evil.example", data={"email": CREDS["admin"][0], "password": CREDS["admin"][1], "csrf_token": s.token()})
    assert resp.status_code == 302 and "evil.example" not in resp.headers["Location"]


def test_csrf_token_required_on_post(app):
    s = Session(app)
    s.login(*CREDS["hr"])
    resp = s.c.post("/departments", data={"name": "Legal"})  # no token
    assert resp.status_code == 400


def test_employee_cannot_open_staff_pages(login):
    emp = login("emp")
    for url in ("/employees", "/payroll/", "/reports", "/audit", "/notifications", "/leave/manage", "/attendance/monthly", "/departments"):
        assert emp.get(url).status_code == 403, url


def test_employee_cannot_use_staff_api(login):
    emp = login("emp")
    assert emp.get("/api/v1/employees").status_code == 403
    assert emp.get("/api/v1/dashboard/charts").status_code == 403


def test_employee_can_only_view_own_profile(app, login):
    emp = login("emp")
    own = emp_id(app, "employee@demo.example")
    other = emp_id(app, "hr@demo.example")
    assert emp.get(f"/employees/{own}").status_code == 200
    assert emp.get(f"/employees/{other}").status_code == 403


def test_hr_and_admin_can_open_staff_pages(login):
    for role in ("hr", "admin"):
        s = login(role)
        for url in ("/employees", "/payroll/", "/reports", "/audit", "/leave/manage", "/"):
            assert s.get(url).status_code == 200, (role, url)


def test_unknown_page_renders_404(login):
    assert login("admin").get("/does-not-exist").status_code == 404


def test_security_headers_present(login):
    resp = login("admin").get("/")
    assert resp.headers["X-Frame-Options"] == "DENY" and "default-src 'self'" in resp.headers["Content-Security-Policy"]


def test_logout_ends_session(login):
    s = login("admin")
    s.post("/logout")
    assert s.get("/employees").status_code == 302
