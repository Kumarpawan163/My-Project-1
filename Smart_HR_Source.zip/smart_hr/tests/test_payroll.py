"""Payroll calculation, access restrictions and controlled payslips."""
import pytest

from apps.core.db import query
from apps.core.validators import ValidationError
from apps.leave_management.services import PermissionDenied
from apps.payroll import services


def u(email):
    return query("SELECT * FROM users WHERE email = ?", (email,), one=True)


def employee(email="employee@demo.example"):
    return query("SELECT e.* FROM employees e JOIN users u ON u.id = e.user_id WHERE u.email = ?", (email,), one=True)


def test_component_validation(ctx):
    eid = employee()["id"]
    with pytest.raises(ValidationError, match="negative"):
        services.set_component(eid, "Bonus", "earning", "-5")
    with pytest.raises(ValidationError, match="number"):
        services.set_component(eid, "Bonus", "earning", "abc")
    with pytest.raises(ValidationError, match="Kind"):
        services.set_component(eid, "Bonus", "gift", "10")
    with pytest.raises(ValidationError, match="required"):
        services.set_component(eid, " ", "earning", "10")


def test_component_upsert_is_audited(ctx):
    eid = employee()["id"]
    services.set_component(eid, "Bonus", "earning", "1000")
    services.set_component(eid, "Bonus", "earning", "1500")
    assert [c["amount"] for c in services.components(eid) if c["name"] == "Bonus"] == [1500.0]
    assert query("SELECT COUNT(*) AS c FROM audit_logs WHERE entity='salary_component'", one=True)["c"] >= 2


def test_record_generation_math(ctx):
    pid = services.create_period(2030, 1)
    created, _ = services.generate_records(pid)
    assert created > 0
    eid = employee()["id"]
    comps = services.components(eid)
    gross = sum(c["amount"] for c in comps if c["kind"] == "earning")
    ded = sum(c["amount"] for c in comps if c["kind"] == "deduction")
    rec = [r for r in services.records_for_period(pid) if r["employee_code"] == employee()["employee_code"]][0]
    assert (rec["gross"], rec["deductions"], rec["net"]) == (gross, ded, gross - ded)


def test_generation_is_idempotent_and_skips_invalid(ctx):
    pid = services.create_period(2030, 2)
    services.generate_records(pid)
    n1 = len(services.records_for_period(pid))
    services.generate_records(pid)
    assert len(services.records_for_period(pid)) == n1
    eid = employee("hr@demo.example")["id"]
    services.set_component(eid, "Huge deduction", "deduction", "99999999")
    pid2 = services.create_period(2030, 3)
    services.generate_records(pid2)
    assert eid not in {r["employee_id"] for r in services.records_for_period(pid2)}


def test_duplicate_period_rejected(ctx):
    services.create_period(2031, 5)
    with pytest.raises(ValidationError, match="already exists"):
        services.create_period(2031, 5)
    with pytest.raises(ValidationError):
        services.create_period(2031, 13)


def test_only_admin_marks_paid(ctx):
    pid = services.create_period(2030, 4)
    services.generate_records(pid)
    rid = services.records_for_period(pid)[0]["id"]
    with pytest.raises(PermissionDenied):
        services.mark_paid(rid, u("hr@demo.example"))
    services.mark_paid(rid, u("admin@demo.example"))
    assert services.get_record(rid)["payment_status"] == "paid"


def test_employee_cannot_generate_payslip(ctx):
    rid = query("SELECT id FROM payroll_records LIMIT 1", one=True)["id"]
    with pytest.raises(PermissionDenied):
        services.generate_payslip(rid, u("employee@demo.example"))


def test_payslip_download_rules(ctx):
    pid = services.create_period(2030, 5)
    services.generate_records(pid)
    rec = [r for r in services.records_for_period(pid) if r["employee_code"] == employee()["employee_code"]][0]
    full = services.get_record(rec["id"])
    owner, other = u("employee@demo.example"), u("hr@demo.example")
    assert not services.can_download(full, owner)  # not generated yet
    services.generate_payslip(rec["id"], other)
    full = services.get_record(rec["id"])
    assert services.can_download(full, owner) and services.can_download(full, other)
    stranger = dict(u("employee@demo.example"))
    stranger["id"] = -1
    assert not services.can_download(full, stranger)
    assert services.payslip_pdf(rec["id"]).startswith(b"%PDF")
    assert query("SELECT 1 FROM notification_logs WHERE template='payslip_ready'", one=True)


def test_http_employee_blocked_from_payroll_admin_pages(login):
    emp = login("emp")
    assert emp.get("/payroll/").status_code == 403
    assert emp.get("/payroll/employee/1").status_code == 403
    assert emp.post("/payroll/record/1/payslip").status_code == 403


def test_http_employee_cannot_download_someone_elses_payslip(app, login):
    with app.app_context():
        mine = employee()["id"]
        other = query("SELECT id FROM payroll_records WHERE employee_id != ? AND payslip_generated_at IS NOT NULL LIMIT 1", (mine,), one=True)["id"]
        own = query("SELECT id FROM payroll_records WHERE employee_id = ? AND payslip_generated_at IS NOT NULL LIMIT 1", (mine,), one=True)["id"]
    emp = login("emp")
    assert emp.get(f"/payroll/record/{other}/download").status_code == 403
    resp = emp.get(f"/payroll/record/{own}/download")
    assert resp.status_code == 200 and resp.mimetype == "application/pdf"


def test_http_hr_cannot_mark_paid(app, login):
    with app.app_context():
        rid = query("SELECT id FROM payroll_records WHERE payment_status='pending' LIMIT 1", one=True)["id"]
    assert login("hr").post(f"/payroll/record/{rid}/paid").status_code == 403
    assert login("admin").post(f"/payroll/record/{rid}/paid").status_code == 302


def test_payroll_kpis(ctx):
    k = services.kpis()
    assert 0 < k["record_completeness"] <= 1 and 0 < k["payslip_success_rate"] <= 1
