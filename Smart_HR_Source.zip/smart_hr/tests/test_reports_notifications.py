"""Dashboards, exports, notification logging and failure handling."""
import io
from datetime import date

from openpyxl import load_workbook

from apps.core import notifications
from apps.core.db import query
from apps.reports import services
from tests.conftest import Session, CREDS


def test_dashboard_chart_api_shape(login):
    data = login("hr").get("/api/v1/dashboard/charts").get_json()
    assert set(data) == {"departments", "attendance", "leave", "payroll"}
    assert sum(d["value"] for d in data["departments"]) >= 20
    assert all({"label", "value"} <= set(d) for d in data["leave"])


def test_staff_and_employee_dashboards_render(login):
    assert b"Workforce dashboard" in login("admin").get("/").data
    assert b"Welcome" in login("emp").get("/").data


def test_csv_export_for_hr(login):
    resp = login("hr").get("/reports/headcount.csv")
    assert resp.status_code == 200 and resp.mimetype == "text/csv"
    lines = resp.data.decode().strip().splitlines()
    assert lines[0] == "Department,Employees" and len(lines) == 6


def test_xlsx_export_is_valid_workbook(login):
    resp = login("hr").get(f"/reports/attendance.xlsx?year={date.today().year}&month={date.today().month}")
    wb = load_workbook(io.BytesIO(resp.data))
    assert wb.active["A1"].value == "Code" and wb.active.max_row > 5


def test_pdf_export_signature(login):
    assert login("admin").get("/reports/leave.pdf").data.startswith(b"%PDF")


def test_exports_forbidden_for_employee_and_unknown_formats_404(login):
    assert login("emp").get("/reports/leave.csv").status_code == 403
    assert login("hr").get("/reports/leave.exe").status_code == 404


def test_payroll_report_requires_period(login):
    assert login("hr").get("/reports/payroll.csv").status_code == 302


def test_csv_neutralises_formula_injection():
    out = services.to_csv(["a"], [["=HYPERLINK(\"http://x\")"], ["+1"], ["safe"]]).decode()
    assert "'=HYPERLINK" in out and "'+1" in out and "safe" in out


def test_export_is_audited(app, login):
    login("hr").get("/reports/headcount.csv")
    with app.app_context():
        assert query("SELECT 1 FROM audit_logs WHERE entity='report' AND details='headcount.csv'", one=True)


def test_notification_failure_is_logged_and_does_not_break_workflow(app):
    app.config.update(EMAIL_BACKEND="smtp", SMTP_HOST="127.0.0.1", SMTP_PORT=1)  # nothing listens here
    with app.app_context():
        ok = notifications.send("payslip_ready", "x@demo.example", name="X", period="Jan 2030")
        assert ok is False
        row = query("SELECT * FROM notification_logs ORDER BY id DESC LIMIT 1", one=True)
        assert row["status"] == "failed" and row["error"]


def test_console_backend_logs_success(app):
    with app.app_context():
        assert notifications.send("payslip_ready", "x@demo.example", name="X", period="Jan 2030") is True
        assert query("SELECT status FROM notification_logs ORDER BY id DESC LIMIT 1", one=True)["status"] == "sent"


def test_audit_page_lists_leave_decisions(login):
    assert b"leave_request" in login("hr").get("/audit?entity=leave_request").data


def test_email_log_page_for_staff_only(login):
    assert login("hr").get("/notifications").status_code == 200
    assert login("emp").get("/notifications").status_code == 403


def test_migrations_are_idempotent(app):
    from apps.core import db
    conn = db.connect(app.config["DATABASE_PATH"])
    assert db.run_migrations(conn) == []
    conn.close()
