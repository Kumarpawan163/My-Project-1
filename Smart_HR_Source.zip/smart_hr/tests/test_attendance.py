"""Attendance recording rules, corrections and monthly summaries."""
from datetime import date, datetime, time

import pytest

from apps.attendance import services
from apps.core.db import query
from apps.core.validators import ValidationError
from tests.conftest import emp_id


def at(h, m):
    return datetime.combine(date.today(), time(h, m))


def employee(email="employee@demo.example"):
    return query("SELECT e.* FROM employees e JOIN users u ON u.id = e.user_id WHERE u.email = ?", (email,), one=True)


def test_on_time_checkin_is_present(ctx):
    _, status = services.check_in(employee(), at(9, 15))
    assert status == "present"


def test_late_checkin_is_marked_late(ctx):
    _, status = services.check_in(employee(), at(10, 5))
    assert status == "late"


def test_duplicate_checkin_rejected(ctx):
    services.check_in(employee(), at(9, 0))
    with pytest.raises(ValidationError, match="already recorded"):
        services.check_in(employee(), at(9, 5))


def test_checkout_requires_checkin(ctx):
    with pytest.raises(ValidationError, match="check in"):
        services.check_out(employee(), at(17, 0))


def test_checkout_must_follow_checkin_and_only_once(ctx):
    services.check_in(employee(), at(9, 0))
    with pytest.raises(ValidationError, match="after check-in"):
        services.check_out(employee(), at(9, 0))
    services.check_out(employee(), at(17, 30))
    with pytest.raises(ValidationError, match="already checked out"):
        services.check_out(employee(), at(18, 0))


def test_terminated_employee_cannot_check_in(ctx):
    emp = dict(employee())
    emp["employment_status"] = "terminated"
    with pytest.raises(ValidationError, match="Terminated"):
        services.check_in(emp, at(9, 0))


def hr_user():
    return query("SELECT * FROM users WHERE email = 'hr@demo.example'", one=True)


def test_correction_requires_reason_and_valid_times(ctx):
    eid = employee()["id"]
    with pytest.raises(ValidationError, match="reason"):
        services.correct(eid, "2026-11-02", "present", "09:00", "17:00", "  ", hr_user())
    with pytest.raises(ValidationError, match="after check-in"):
        services.correct(eid, "2026-11-02", "present", "17:00", "09:00", "typo", hr_user())
    with pytest.raises(ValidationError, match="status"):
        services.correct(eid, "2026-11-02", "holiday", "", "", "x", hr_user())


def test_correction_updates_record_audits_and_notifies(ctx):
    eid = employee()["id"]
    services.correct(eid, "2026-11-03", "present", "09:10", "17:45", "Badge reader failed", hr_user())
    row = query("SELECT * FROM attendance WHERE employee_id = ? AND work_date = '2026-11-03'", (eid,), one=True)
    assert row["status"] == "present" and row["correction_reason"] == "Badge reader failed" and row["corrected_by"] == hr_user()["id"]
    assert query("SELECT 1 FROM audit_logs WHERE entity='attendance' AND action='corrected'", one=True)
    assert query("SELECT 1 FROM notification_logs WHERE template='attendance_correction' AND status='sent'", one=True)


def test_employee_role_cannot_correct_via_service(ctx):
    emp_user = query("SELECT * FROM users WHERE email = 'employee@demo.example'", one=True)
    with pytest.raises(ValidationError, match="Only HR"):
        services.correct(employee()["id"], "2026-11-03", "present", "", "", "self edit", emp_user)


def test_employee_cannot_correct_via_http(app, login):
    resp = login("emp").get(f"/attendance/employee/{emp_id(app, 'employee@demo.example')}")
    assert resp.status_code == 403


def test_monthly_summary_matches_raw_rows(ctx):
    today = date.today()
    rows = services.monthly_report(today.year, today.month)
    raw = query("SELECT COUNT(*) AS c FROM attendance WHERE work_date BETWEEN ? AND ?", services.month_bounds(today.year, today.month), one=True)["c"]
    assert sum(r["days_recorded"] for r in rows) == raw
    for r in rows:
        assert (r["present"] or 0) + (r["late"] or 0) + (r["absent"] or 0) + (r["half_day"] or 0) + (r["on_leave"] or 0) == r["days_recorded"]


def test_checkin_via_http_flow(login):
    emp = login("emp")
    assert b"Checked" in emp.post("/attendance/check-in", follow_redirects=True).data
    again = emp.post("/attendance/check-in", follow_redirects=True)
    assert b"already recorded" in again.data
