import shutil
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app import create_app  # noqa: E402
from apps.core.db import query  # noqa: E402
from scripts.seed_demo_data import seed  # noqa: E402


@pytest.fixture(scope="session")
def seeded_template(tmp_path_factory):
    """Seed the synthetic dataset once; every test gets its own copy of the file."""
    path = tmp_path_factory.mktemp("seed") / "template.sqlite3"
    app = create_app(TESTING=True, DATABASE_PATH=str(path), SECRET_KEY="test-secret")
    with app.app_context():
        seed()
    return path


@pytest.fixture()
def app(tmp_path, seeded_template):
    db_path = tmp_path / "test.sqlite3"
    shutil.copy(seeded_template, db_path)
    return create_app(TESTING=True, DATABASE_PATH=str(db_path), SECRET_KEY="test-secret")


@pytest.fixture()
def ctx(app):
    with app.app_context():
        yield


class Session:
    """Test client wrapper that logs in through the real login form (CSRF included)."""

    def __init__(self, app):
        self.c = app.test_client()
        self.app = app

    def token(self):
        with self.c.session_transaction() as s:
            s.setdefault("csrf", "t" * 32)
            return s["csrf"]

    def login(self, email, password):
        return self.c.post("/login", data={"email": email, "password": password, "csrf_token": self.token()})

    def post(self, url, data=None, **kw):
        data = dict(data or {})
        data["csrf_token"] = self.token()
        return self.c.post(url, data=data, **kw)

    def get(self, url, **kw):
        return self.c.get(url, **kw)


CREDS = {"admin": ("admin@demo.example", "Admin@12345"), "hr": ("hr@demo.example", "Hr@12345"), "emp": ("employee@demo.example", "Employee@123")}


@pytest.fixture()
def login(app):
    def _login(role):
        s = Session(app)
        resp = s.login(*CREDS[role])
        assert resp.status_code == 302, "login failed"
        return s
    return _login


def emp_id(app, email):
    with app.app_context():
        return query("SELECT e.id FROM employees e JOIN users u ON u.id = e.user_id WHERE u.email = ?", (email,), one=True)["id"]
