"""Employee, department and account management rules."""
import pytest

from apps.core.db import query
from apps.core.validators import ValidationError
from apps.employees import services
from tests.conftest import CREDS, Session


def form(**over):
    base = {"full_name": "Test Person", "email": "test.person@demo.example", "password": "Password@1", "role": "employee",
            "job_title": "Analyst", "department_id": "", "joining_date": "2026-01-05", "employment_status": "active", "phone": ""}
    base.update(over)
    return base


def test_create_employee_and_audit(ctx):
    eid = services.create_employee(form())
    assert services.get_employee(eid)["employee_code"].startswith("EMP")
    assert query("SELECT 1 FROM audit_logs WHERE entity = 'employee' AND entity_id = ? AND action = 'created'", (eid,), one=True)


@pytest.mark.parametrize("bad,msg", [
    ({"full_name": " "}, "Full name"), ({"email": "nope"}, "Email"), ({"password": "short"}, "Password"),
    ({"joining_date": "05/01/2026"}, "Joining date"), ({"employment_status": "retired"}, "status"), ({"department_id": "999"}, "Department"),
])
def test_validation_errors(ctx, bad, msg):
    with pytest.raises(ValidationError) as exc:
        services.create_employee(form(**bad))
    assert msg.lower() in str(exc.value).lower()


def test_duplicate_email_rejected(ctx):
    with pytest.raises(ValidationError):
        services.create_employee(form(email="employee@demo.example"))


def test_search_filter_and_pagination(ctx):
    rows, total = services.search_employees(page=1, page_size=5)
    assert len(rows) == 5 and total >= 20
    rows2, _ = services.search_employees(page=2, page_size=5)
    assert {r["id"] for r in rows}.isdisjoint({r["id"] for r in rows2})
    found, n = services.search_employees(q="esha")
    assert n == 1 and found[0]["full_name"] == "Esha Rao"
    dept = query("SELECT id FROM departments WHERE name = 'Sales'", one=True)["id"]
    _, n_sales = services.search_employees(department_id=dept)
    assert 0 < n_sales < total


def test_department_duplicate_name_rejected(ctx):
    with pytest.raises(ValidationError):
        services.create_department("engineering")


def test_status_change_is_audited_and_termination_blocks_login(app, login):
    hr = login("hr")
    with app.app_context():
        eid = query("SELECT e.id FROM employees e JOIN users u ON u.id = e.user_id WHERE u.email = 'employee@demo.example'", one=True)["id"]
    resp = hr.post(f"/employees/{eid}/edit", {"full_name": "Esha Rao", "job_title": "Software Engineer", "department_id": "1",
                                              "joining_date": "2024-01-01", "employment_status": "terminated", "phone": "1"})
    assert resp.status_code == 302
    with app.app_context():
        assert query("SELECT 1 FROM audit_logs WHERE entity='employee' AND entity_id=? AND details LIKE '%employment_status%'", (eid,), one=True)
    assert Session(app).login(*CREDS["emp"]).status_code == 200  # login refused


def test_api_lists_employees_for_hr(login):
    data = login("hr").get("/api/v1/employees?q=esha").get_json()
    assert data["total"] == 1 and data["results"][0]["full_name"] == "Esha Rao"
