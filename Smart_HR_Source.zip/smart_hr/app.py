"""Application factory for the Smart HR & Employee Management System."""
import logging
from datetime import timedelta

from flask import Flask, jsonify, render_template, request

from apps.core import db, logging_setup, security
from config.settings import Config

log = logging.getLogger("smart_hr")


def create_app(**overrides):
    cfg = Config(**overrides)
    logging_setup.configure(cfg.LOG_LEVEL)
    app = Flask(__name__, template_folder="templates", static_folder="static")
    app.config.from_object(cfg)
    app.config.update(
        SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax", PERMANENT_SESSION_LIFETIME=timedelta(hours=8),
    )

    # Apply pending migrations on start-up.
    conn = db.connect(app.config["DATABASE_PATH"])
    db.run_migrations(conn)
    conn.close()
    app.teardown_appcontext(db.close_db)

    from apps.accounts.routes import bp as accounts_bp
    from apps.attendance.routes import bp as attendance_bp
    from apps.employees.routes import bp as employees_bp
    from apps.leave_management.routes import bp as leave_bp
    from apps.payroll.routes import bp as payroll_bp
    from apps.reports.routes import bp as reports_bp

    for bp in (accounts_bp, employees_bp, attendance_bp, leave_bp, payroll_bp, reports_bp):
        app.register_blueprint(bp)

    @app.before_request
    def _before():
        security.load_current_user()
        security.check_csrf()

    # A Jinja global (not a context variable) so imported macros such as csrf() can call it too.
    app.jinja_env.globals["csrf_token"] = security.csrf_token

    @app.context_processor
    def _inject():
        from flask import g
        return {"current_user": g.get("user"), "current_employee": g.get("employee")}

    @app.after_request
    def _headers(resp):
        resp.headers["X-Content-Type-Options"] = "nosniff"
        resp.headers["X-Frame-Options"] = "DENY"
        resp.headers["Referrer-Policy"] = "same-origin"
        resp.headers["Content-Security-Policy"] = "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'"
        return resp

    def _error(code, title):
        def handler(exc):
            if "/api/" in request.path:
                return jsonify(error=title), code
            return render_template("error.html", code=code, title=title, detail=getattr(exc, "description", "")), code
        return handler

    for code, title in ((400, "Bad request"), (403, "Access denied"), (404, "Not found")):
        app.register_error_handler(code, _error(code, title))

    @app.errorhandler(500)
    def _server_error(exc):
        log.exception("unhandled error")
        return _error(500, "Something went wrong")(exc)

    return app


if __name__ == "__main__":
    create_app(DEBUG=True).run(host="127.0.0.1", port=5000)
